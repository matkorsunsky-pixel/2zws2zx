# -*- coding: utf-8 -*-
"""Дополнения к основному файлу при сборке (исходники вех не меняются).

transform(имя_файла, текст) -> текст с метками вех, полосами времени, эпиграфами,
карточками деятелей, «Запомнить для ЕГЭ» и титульными страницами частей.
Картинки, которые можно добавить вручную:
  src/media/portraits/<slug>.jpg — портрет деятеля (slug — см. audit/images_todo.md),
  src/media/art/veha_<код>.jpg   — картина эпохи к вехе.
"""
import os, re
import extras_data as D

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(HERE), 'src')
BANDS = os.path.join(SRC, 'media', 'bands')

TR = dict(zip('абвгдеёжзийклмнопрстуфхцчшщъыьэюя', ['a', 'b', 'v', 'g', 'd', 'e', 'e', 'zh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'ts', 'ch', 'sh', 'sch', '', 'y', '', 'e', 'yu', 'ya']))

def slug(name):
    s = ''.join(TR.get(c, c) for c in name.lower())
    return re.sub(r'[^a-z0-9]+', '_', s).strip('_')

def div(style, text):
    return '::: {custom-style="%s"}\n%s\n:::\n' % (style, text)

def veha_label(code):
    return 'Веха ' + code.replace('_', '.').lstrip('0') if not code.startswith('0_') else 'Веха ' + code.replace('_', '.')

# ---------------------------------------------------------------- полоса времени
def band_png(code, y0, y1, label):
    os.makedirs(BANDS, exist_ok=True)
    p = os.path.join(BANDS, 'band_%s.png' % code)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle, Polygon
    A, B = 850, 2026
    fig = plt.figure(figsize=(6.7, 0.62), dpi=200)
    ax = fig.add_axes([0.005, 0.0, 0.99, 1.0]); ax.set_xlim(A - 6, B + 14); ax.set_ylim(0, 1); ax.axis('off')
    for a, b, part in D.BAND:
        c = '#' + D.PARTS[part]['color']
        ax.add_patch(Rectangle((a, 0.30), b - a, 0.13, fc=c, ec='white', lw=0.6, alpha=0.38))
    for yr in range(900, 2001, 100):
        ax.plot([yr, yr], [0.25, 0.30], color='#777', lw=0.5)
        ax.text(yr, 0.02, '%d' % yr, ha='center', va='bottom', fontsize=4.6, color='#666', family='DejaVu Sans')
    w = max(y1 - y0, 4)
    part = next((pp for a, b, pp in D.BAND if a <= y0 < b), 'IX')
    c = '#' + D.PARTS[part]['color']
    ax.add_patch(Rectangle((y0, 0.27), w, 0.19, fc=c, ec='#222', lw=0.5))
    xm = y0 + w / 2.0
    ax.add_patch(Polygon([[xm - 7, 0.62], [xm + 7, 0.62], [xm, 0.48]], closed=True, fc=c, ec='none'))
    ha = 'left' if xm < A + 140 else 'right' if xm > B - 140 else 'center'
    ax.text(xm, 0.64, label, ha=ha, va='bottom', fontsize=5.6, color=c, weight='bold', family='DejaVu Sans')
    fig.savefig(p, dpi=200, transparent=False, facecolor='white')
    plt.close(fig)
    try:
        from PIL import Image
        im = Image.open(p).convert('RGB').quantize(colors=48)
        im.save(p, optimize=True)
    except Exception:
        pass
    return 'media/bands/band_%s.png' % code

# ---------------------------------------------------------------- вставки
def portrait_path(name):
    """Файл портрета: media/portraits/<slug>.jpg (или None)."""
    s = slug(name)
    return 'media/portraits/%s.jpg' % s if os.path.exists(os.path.join(SRC, 'media', 'portraits', s + '.jpg')) else None

ART_CREDIT = {}   # veha_<код>.jpg -> дополнительная подпись (условное изображение и т. п.), см. load_credits()

def load_credits():
    """Пометки к картинкам из audit/images_credits.md: «условное изображение» и т. п. (колонка «Пометка»)."""
    p = os.path.join(os.path.dirname(SRC), 'audit', 'images_credits.md')
    out = {}
    if not os.path.exists(p): return out
    for l in open(p, encoding='utf8'):
        c = [x.strip() for x in l.strip().strip('|').split('|')]
        if len(c) >= 7 and c[0].startswith('`') and c[6] and c[6] != '—':
            out[c[0].strip('`')] = c[6]
    return out
NOTES = load_credits()

def people_block(code, d):
    """Рамка «Ключевые деятели»: деятели с портретом — карточками (style_docx.people_grid собирает
    их в таблицу без рамок: портрет слева, имя / годы / «чем знаменит» справа, по 2 в ряд);
    деятели без портрета — списком ниже."""
    ppl = d.get('ppl') or []
    art = d.get('art')
    if not ppl and not art: return ''
    L = ['#### Ключевые деятели' if ppl else '#### Картина эпохи', '']
    withp = [(n, y, l, portrait_path(n)) for n, y, l in ppl if portrait_path(n)]
    nop = [(n, y, l) for n, y, l in ppl if not portrait_path(n)]
    for name, yrs, line, pic in withp:
        note = NOTES.get(os.path.basename(pic))
        L += [div('PersonPic', '![](%s){height="1.05in"}' % pic), div('PersonName', '**%s**' % name),
              div('PersonInfo', '%s — %s' % (yrs, line))] + ([div('PersonNote', 'Портрет: %s' % note)] if note else []) + ['']
    for name, yrs, line in nop:
        L.append('-   **%s** (%s) — %s' % (name, yrs, line))
    if art:
        L.append('')
        aimg = os.path.join(SRC, 'media', 'art', 'veha_%s.jpg' % code)
        if os.path.exists(aimg):
            if ppl: L += ['#### Картина эпохи', '']    # отдельная рамка: крупная картинка не утаскивает деятелей на новую страницу
            note = NOTES.get('veha_%s.jpg' % code)
            cap = '«%s» (%s)' % (art[0], art[1]) + ('' if not note else ' — %s' % note)
            wid = 5.2
            try:
                from PIL import Image
                iw, ih = Image.open(aimg).size
                wid = min(5.2, 3.0 * iw / ih)      # не выше 3 дюймов: рамка с картиной чаще умещается на странице с деятелями
            except Exception:
                pass
            L.append('![Картина эпохи: %s](media/art/veha_%s.jpg){width="%.2fin"}' % (cap, code, wid))
        else:
            L.append(('*Картина эпохи:* ' if ppl else '') + '«%s» (%s) — найдите и рассмотрите её: детали картины помогают запомнить эпоху.' % art)
    return '\n'.join(L) + '\n'

def ege_block(d):
    e = d.get('ege') or []
    if not e: return ''
    def b(x):
        a, sep, rest = x.partition(' — ')
        return ('**%s** — %s' % (a, rest)) if sep and len(a) < 60 else x
    return '#### Запомнить для ЕГЭ\n\n' + '\n'.join('-   ' + b(x) for x in e) + '\n'

def transform_veha(code, text):
    d = D.V.get(code, {})
    yl = d.get('yl', '')
    lines = text.split('\n')
    out = []
    i = 0
    # метка над заголовком
    k = next(n for n, l in enumerate(lines) if l.startswith('## '))
    out += lines[:k]
    out.append(div('VehaTag', veha_label(code) + (' · ' + yl if yl else '')))
    out.append(lines[k]); out.append('')
    if d.get('y'):
        out.append('![](%s){width="6.7in"}' % band_png(code, d['y'][0], d['y'][1], yl)); out.append('')
    if d.get('epi'):
        q, who = d['epi']
        q = q if q.startswith('«') else '«' + q + '»'
        out.append(div('Epigraph', q)); out.append(div('EpigraphAuthor', '— ' + who))
    rest = lines[k + 1:]
    # после абзаца «Суть вехи»
    j = next((n for n, l in enumerate(rest) if l.startswith('**Суть вехи')), None)
    pb = people_block(code, d)
    if j is not None and pb:
        e = j
        while e < len(rest) and rest[e].strip(): e += 1
        rest = rest[:e] + ['', pb] + rest[e:]
    out += rest
    t = '\n'.join(out).rstrip('\n') + '\n\n' + ege_block(d)
    return t

def transform_part(key, text):
    P = D.PARTS.get(key)
    if not P: return text
    lines = text.split('\n')
    k = next(n for n, l in enumerate(lines) if l.startswith('# '))
    out = lines[:k + 1] + ['']
    rest = lines[k + 1:]
    # строка годов курсивом — заменяем крупной
    yrs = P['years']
    for n, l in enumerate(rest):
        m = re.match(r'^\*(.+)\*\s*$', l.strip())
        if m:
            yrs = m.group(1); del rest[n]; break
    out.append(div('PartYears', yrs))
    wid = 6.7
    try:
        from PIL import Image
        iw, ih = Image.open(os.path.join(SRC, 'media', P['map'])).size
        wid = min(6.7, 5.3 * iw / ih)
    except Exception:
        pass
    out.append('![](media/%s){width="%.2fin"}' % (P['map'], wid)); out.append('')
    out.append('#### Главные события эпохи'); out.append('')
    out += ['-   ' + e for e in P['ev']]
    out.append('')
    return '\n'.join(out + rest)

def transform_svod(text):
    def rep(m):
        t = m.group(1)
        yrs = re.findall(r'\(([^()]*\d[^()]*)\)\s*$', t)
        y = re.sub(r'\s*гг?\.\s*$', '', yrs[-1]) if yrs else ''
        return div('VehaTag', 'Свод эпохи' + (' · ' + y if y else '')) + '\n## ' + t
    return re.sub(r'^## (Свод эпохи.*)$', rep, text, flags=re.M)

def transform(fname, text):
    m = re.search(r'_veha_(\w+)\.md$', fname)
    if m: return transform_veha(m.group(1), text)
    m = re.search(r'_chast_([0IVX]+)\.md$', fname)
    if m: return transform_part(m.group(1), text)
    if '_svod_' in fname: return transform_svod(text)
    return text

def images_todo(path):
    """Список картинок, которые можно добавить вручную."""
    L = ['# Картинки к вехам: что можно добавить', '',
         'Положите файл JPG с указанным именем в папку и пересоберите материал — картинка встанет сама.', '',
         '## Портреты — папка src/media/portraits/', '']
    seen = set()
    for code, d in D.V.items():
        for name, yrs, line in d.get('ppl') or []:
            s = slug(name)
            if s in seen: continue
            seen.add(s); L.append('- `%s.jpg` — %s (%s)' % (s, name, yrs))
    L += ['', '## Картины эпохи — папка src/media/art/', '']
    for code, d in D.V.items():
        if d.get('art'): L.append('- `veha_%s.jpg` — «%s» (%s)' % (code, d['art'][0], d['art'][1]))
    open(path, 'w', encoding='utf8').write('\n'.join(L) + '\n')

# ======================================================================== этап 3
import extras_data2 as D2

CTX = {'files': [], 'codes': set(), 'src': SRC}
PART_VEHAS = {'0': ['0_1', '0_2', '0_3', '0_4', '0_5', '0_6'], 'I': ['%02d' % i for i in range(1, 12)], 'II': ['%02d' % i for i in range(12, 20)],
              'III': ['%02d' % i for i in range(20, 25)], 'IV': ['%02d' % i for i in range(25, 34)], 'V': ['%02d' % i for i in range(34, 41)],
              'VI': ['%02d' % i for i in range(41, 45)], 'VII': ['%02d' % i for i in range(45, 55)], 'VIII': ['%02d' % i for i in range(55, 59)],
              'IX': ['%02d' % i for i in range(59, 68)]}
PART_TITLES = {'0': 'Часть 0. Древнейшая история', 'I': 'Часть I. Истоки Руси', 'II': 'Часть II. Ордынский период', 'III': 'Часть III. Иван Грозный и Смута',
               'IV': 'Часть IV. Романовы и империя', 'V': 'Часть V. XIX век', 'VI': 'Часть VI. Николай II', 'VII': 'Часть VII. 1918–1953',
               'VIII': 'Часть VIII. 1953–1991', 'IX': 'Часть IX. Новая Россия'}

def set_ctx(files):
    CTX['files'] = list(files)
    CTX['codes'] = {m.group(1) for f in files for m in [re.search(r'_veha_(\w+)\.md$', f)] if m}

def aid(code): return 'v' + code.replace('_', '-')
def num(code): return code.replace('_', '.').lstrip('0') if not code.startswith('0_') else code.replace('_', '.')
def vlink(code, text=None):
    t = text or ('веха ' + num(code))
    return '[%s](#%s)' % (t, aid(code)) if code in CTX['codes'] else t

def conn_block(code):
    c = D2.CONN.get(code)
    if not c or not (c[0] or c[1]): return ''
    L = ['#### Связь с другими вехами', '']
    for k, why in c[0]: L.append('-   **Откуда:** %s — %s' % (vlink(k).capitalize() if k not in CTX['codes'] else vlink(k, 'Веха ' + num(k)), why))
    for k, why in c[1]: L.append('-   **Что дальше:** %s — %s' % (vlink(k, 'Веха ' + num(k)) if k in CTX['codes'] else 'Веха ' + num(k), why))
    return '\n'.join(L) + '\n'

def qa_block(code):
    qa = D2.QA.get(code)
    if not qa: return ''
    L = ['#### Проверь себя', '']
    for n, (q, a) in enumerate(qa, 1): L.append('%d.  %s' % (n, q))
    L += ['', '*Ответы — в разделе [«Ответы на вопросы „Проверь себя“»](#answers) в конце файла.*']
    return '\n'.join(L) + '\n'

def part_of(code):
    return next((p for p, vs in PART_VEHAS.items() if code in vs), None)

def cheat_sheet(part):
    vs = [v for v in PART_VEHAS[part] if v in CTX['codes']]
    P = D.PARTS[part]
    L = [div('VehaTag', '[]{#cs-%s}Шпаргалка · %s' % (part, P['years'])), '## Шпаргалка: %s' % PART_TITLES[part], '',
         '*Всё главное по части на одной-двух страницах — для повторения перед экзаменом.*', '']
    rows = []
    for v in vs:
        for e in D.V.get(v, {}).get('ege') or []:
            a, sep, b = e.partition(' — ')
            if sep and re.search(r'\d', a) and len(a) < 45: rows.append((a, b, v))
    if rows:
        L += ['### Даты', '', '| Когда | Что | Веха |', '|------|-----------------------------|----|']
        L += ['| %s | %s | %s |' % (a, b.replace('|', '/'), vlink(v, num(v))) for a, b, v in rows]
        L.append('')
    ppl = []
    for v in vs:
        for n, y, l in D.V.get(v, {}).get('ppl') or []:
            if n not in [x[0] for x in ppl]: ppl.append((n, y, l))
    if ppl:
        L += ['### Люди', '', '; '.join('**%s** (%s)' % (n, y) for n, y, l in ppl) + '.', '']
    t = D2.TERMS.get(part)
    if t:
        L += ['### Понятия', '', '| Понятие | Значение |', '|--------|--------------------------|']
        L += ['| **%s** | %s |' % (a, b) for a, b in t]
        L.append('')
    return '\n'.join(L) + '\n'

_old_transform_veha = transform_veha
def transform_veha(code, text):
    t = _old_transform_veha(code, text)
    # метка-якорь
    t = t.replace('::: {custom-style="VehaTag"}\n', '::: {custom-style="VehaTag"}\n[]{#%s}' % aid(code), 1)
    ege = ege_block(D.V.get(code, {}))
    body = t[:len(t) - len(ege)] if ege and t.endswith(ege) else t
    t = body.rstrip('\n') + '\n\n' + conn_block(code) + '\n' + qa_block(code) + '\n' + ege
    p = part_of(code)
    if p and code == [v for v in PART_VEHAS[p] if v in CTX['codes']][-1]:
        t = t.rstrip('\n') + '\n\n' + cheat_sheet(p)
    return t

_old_transform_part = transform_part
def transform_part(key, text):
    t = _old_transform_part(key, text)
    return t.replace('::: {custom-style="PartYears"}\n', '::: {custom-style="PartYears"}\n[]{#p-%s}' % key, 1)

def transform(fname, text):
    m = re.search(r'_veha_(\w+)\.md$', fname)
    if m: return transform_veha(m.group(1), text)
    m = re.search(r'_chast_([0IVX]+)\.md$', fname)
    if m: return transform_part(m.group(1), text)
    if '_svod_' in fname: return transform_svod(text)
    return text

def is_full():
    return {v for vs in PART_VEHAS.values() for v in vs} <= CTX['codes']

def head():
    if not is_full(): return ''
    L = ['# Карта материала', '', '*Нажмите на часть или номер вехи, чтобы перейти к ней (в Word — Ctrl + щелчок).*', '',
         '| Часть | Годы | Вехи |', '|------------|-----------|-----------------------------------|']
    for p, vs in PART_VEHAS.items():
        P = D.PARTS[p]
        cells = ' · '.join(vlink(v, num(v)) for v in vs) + ' · [шпаргалка](#cs-%s)' % p
        L.append('| [%s](#p-%s) | %s | %s |' % (P['short'], p, P['years'], cells))
    L += ['', '**В конце файла:** [ответы на вопросы «Проверь себя»](#answers) · [именной указатель](#index).', '']
    return '\n'.join(L) + '\n'

# ---------------------------------------------------------------- именной указатель
EPI = {'Вещий', 'Мудрый', 'Мономах', 'Великий', 'Долгорукий', 'Боголюбский', 'Гнездо', 'Невский', 'Калита', 'Донской', 'Тёмный',
       'Грозный', 'Окаянный', 'Тишайший', 'Освободитель', 'Миротворец', 'Галицкий', 'Тверской', 'Рюрикович', 'Игоревич', 'Святославич',
       'Изяславич', 'Мстиславич', 'Ярославич', 'Александрович', 'Всеволодович', 'Фёдорович', 'Алексеевич', 'Михайлович', 'Иоаннович',
       'Петровна', 'Иоанновна', 'Шемяка', 'Радонежский', 'Цимисхий', 'Палеолог', 'Глинская', 'Сорский', 'Волоцкий', 'Севастопольская'}
RX = {
 'Кий, Щек, Хорив и Лыбедь': r'Щек', 'Нестор': r'\bНестор\w{0,2}\b', 'Рюрик': r'\bРюрик(?:а|у|ом|е)?\b', 'Аскольд и Дир': r'\bАскольд',
 'Олег Вещий': r'\bОлег(?:а|у|ом|е)?\b', 'Игорь Рюрикович': r'\bИгор(?:ь|я|ю|ем|е)\b(?!\s+Святославич)', 'Ольга': r'\bОльг(?:а|и|е|у|ой)\b',
 'Святослав Игоревич': r'\bСвятослав(?:а|у|ом|е)?\b(?!\s+(?:Ольгович|Ярославич|Всеволодович|Мстиславич))', 'Иоанн Цимисхий': r'Цимисхи',
 'Владимир Святославич': r'Владимир\w{0,2} Святославич|князь Владимир\b|князя Владимира\b|Владимир\w{0,2} Креститель',
 'Ярополк Святославич': r'\bЯрополк', 'Ярослав Мудрый': r'Ярослав\w{0,2} Мудр|Правд\w Ярослава|Ярослав(?:а|у|ом)? (?:Владимирович)',
 'Борис и Глеб': r'Борис\w{0,2} и Глеб', 'Святополк Окаянный': r'Святополк\w{0,2}\b(?!\s+Изяслав)', 'Иларион': r'\bИларион',
 'Владимир Мономах': r'Мономах', 'Святополк Изяславич': r'Святополк\w{0,2} Изяславич', 'Мстислав Великий': r'Мстислав\w{0,2} Велик',
 'Юрий Долгорукий': r'Долгорук', 'Андрей Боголюбский': r'Боголюбск(?:ий|ого|ому|им|ом)\b', 'Всеволод Большое Гнездо': r'Больш\w+ Гнезд',
 'Всеволод Мстиславич': r'Всеволод\w{0,2} Мстиславич', 'Даниил Романович Галицкий': r'Даниил\w{0,2} (?:Романович|Галицк)',
 'Чингисхан': r'Чингисхан', 'Батый': r'\bБаты[йяюе]', 'Юрий Всеволодович': r'Юри\w{1,2} Всеволодович', 'Евпатий Коловрат': r'Коловрат',
 'Александр Невский': r'Александр\w{0,2} (?:Ярославич|Невск)|\bНевск(?:ий|ого|ому|им)\b', 'Миндовг': r'Миндовг',
 'Андрей Ярославич': r'Андре\w{1,2} Ярославич', 'Даниил Александрович': r'Даниил\w{0,2} (?:Александрович|Московск)', 'Иван Калита': r'Калит',
 'Михаил Ярославич Тверской': r'Михаил\w{0,2} (?:Ярославич|Тверск)', 'Митрополит Пётр': r'[Мм]итрополит\w{0,2} П[её]тр',
 'Дмитрий Донской': r'Дмитри\w{1,2} (?:Донск|Иванович)', 'Сергий Радонежский': r'Серги[йяюе]\b|Радонежск', 'Митрополит Алексий': r'[Мм]итрополит\w{0,2} Алекси',
 'Мамай': r'\bМама[йяюе]\b', 'Василий I': r'Васили\w{0,2} I\b(?!I)|Васили\w{0,2} Дмитриевич', 'Василий II Тёмный': r'Васили\w{0,2} II\b(?!I)|Тёмн(?:ый|ого|ому)\b',
 'Дмитрий Шемяка': r'Шемяк', 'Витовт': r'Витовт', 'Ахмат': r'\bАхмат(?:а|у|ом|е)?\b', 'Иван III': r'Иван\w{0,2} III\b', 'Софья Палеолог': r'Софь\w{1,2} Палеолог',
 'Аристотель Фиораванти': r'Фиораванти', 'Василий III': r'Васили\w{0,2} III\b', 'Филофей': r'Филофе', 'Иосиф Волоцкий': r'Иосиф\w{0,2} Волоцк',
 'Нил Сорский': r'Нил\w{0,2} Сорск', 'Иван IV Грозный': r'Иван\w{0,2} IV\b|Иван\w{0,2} Грозн', 'Елена Глинская': r'Елен\w{1,2} Глинск',
 'Митрополит Макарий': r'Макари', 'Стефан Баторий': r'Батори', 'Ермак': r'\bЕрмак(?:а|у|ом|е)?\b', 'Фёдор Иоаннович': r'Фёдор\w{0,2} Иоаннович',
 'Царевич Дмитрий': r'[Цц]аревич\w{0,2} Дмитри', 'Патриарх Иов': r'\bИов(?:а|у|ом)?\b', 'Лжедмитрий I': r'Лжедмитри\w{0,2} I\b(?!I)',
 'Лжедмитрий II': r'Лжедмитри\w{0,2} II\b|Тушинск\w+ вор', 'Василий Шуйский': r'Васили\w{0,2} Шуйск|В\. И\. Шуйск|царя? Шуйск',
 'Михаил Скопин-Шуйский': r'Скопин', 'Патриарх Гермоген': r'Гермоген', 'Михаил Фёдорович': r'Михаил\w{0,2} Фёдорович|Михаил\w{0,2} Романов',
 'Патриарх Филарет': r'Филарет', 'Алексей Михайлович': r'Алексе\w{1,2} Михайлович', 'Борис Морозов': r'Б\. И\. Морозов|Борис\w{0,2} Морозов',
 'Боярыня Морозова': r'[Бб]оярын\w+ Морозов|Ф\. П\. Морозов', 'Патриарх Никон': r'\bНикон(?:а|у|ом|е)?\b', 'Протопоп Аввакум': r'Аввакум',
 'Фёдор Алексеевич': r'Фёдор\w{0,2} Алексеевич', 'Царевна Софья': r'\bСофь(?:я|и|ей|ю)\b(?!\s+Палеолог)', 'Василий Голицын': r'В\. В\. Голицын|Васили\w{0,2} Голицын',
 'Пётр I': r'П[её]тр\w{0,2} I\b(?!I)|П[её]тр\w{0,2} Велик', 'Карл XII': r'Карл\w{0,2} XII', 'Екатерина I': r'Екатерин\w{0,2} I\b(?!I)',
 'Анна Иоанновна': r'Анн\w{1,2} Иоанновн', 'Елизавета Петровна': r'Елизавет\w{1,2} Петровн', 'Екатерина II': r'Екатерин\w{0,2} II\b(?!I)',
 'Павел I': r'Пав(?:ел|ла|лу|лом|ле) I\b(?!I)', 'Александр I': r'Александр\w{0,2} I\b(?!I)', 'Наполеон I': r'Наполеон', 'Николай I': r'Никола\w{1,2} I\b(?!I)',
 'Александр II Освободитель': r'Александр\w{0,2} II\b(?!I)', 'Александр III Миротворец': r'Александр\w{0,2} III\b', 'Николай II': r'Никола\w{1,2} II\b(?!I)',
 'Николай Милютин': r'Н\. А\. Милютин|Никола\w{1,2} Милютин', 'Дмитрий Милютин': r'Д\. А\. Милютин|Дмитри\w{1,2} Милютин',
 'Дарья Севастопольская': r'Дарь\w{1,2} Севастопольск', 'Пётр Багратион': r'(?<!«)Багратион\w{0,3}\b(?!»)', 'Григорий Потёмкин': r'(?<!«)Потёмкин\w{0,3}\b(?!»)',
 'Никита Муравьёв': r'Н\. М\. Муравь|Никит\w{1,2} Муравь', 'Владимир Корнилов': r'В\. А\. Корнилов|адмирал\w{0,2} Корнилов',
 'Павел Киселёв': r'П\. Д\. Киселёв|Павл?\w{1,2} Киселёв|реформ\w* Киселёва', 'Яков Павлов': r'Я\. Ф\. Павлов|[Дд]ом\w{0,2} Павлова',
 'Александр Яковлев': r'А\. Н\. Яковлев', 'Михаил Барклай-де-Толли': r'Барклай', 'Михаил Лорис-Меликов': r'Лорис-Меликов',
 'Афанасий Ордин-Нащокин': r'Ордин-Нащокин', 'Александр Лебедь': r'\bЛебед(?:ь|я|ю|ем)\b',
}
SKIP = {'Михаил Романов', 'Алексей Михайлович Тишайший'}
NEAR = {'Святослав Игоревич', 'Олег Вещий', 'Игорь Рюрикович', 'Ольга', 'Рюрик', 'Ярополк Святославич', 'Святополк Окаянный', 'Ахмат', 'Мамай',
        'Царевна Софья', 'Патриарх Никон', 'Патриарх Иов', 'Нестор', 'Ермак', 'Владимир Святославич', 'Иларион', 'Батый', 'Филарет', 'Патриарх Филарет'}

def person_rx(name):
    if name in RX: return RX[name]
    w = name.split()
    sur = w[-1]
    if re.search(r'(?:ский|цкий|ской)$', sur): return r'\b%s(?:ий|ого|ому|им|ом|ой|ая|ую)\b' % sur[:-2]
    if re.search(r'(?:ская|цкая)$', sur): return r'\b%s(?:ая|ой|ую)\b' % sur[:-2]
    if re.search(r'[бвгджзклмнпрстфхцчшщ]$', sur): return r'\b%s(?!ск)\w{0,3}\b' % sur
    return r'\b%s\b' % sur

def display(name, yrs):
    w = name.split()
    if name in RX or len(w) == 1 or w[-1] in EPI or re.fullmatch(r'[IVX]+', w[-1]) or w[0] in ('Митрополит', 'Патриарх', 'Протопоп', 'Царевич', 'Царевна', 'Боярыня'):
        return '%s (%s)' % (name, yrs), name
    return '%s %s (%s)' % (w[-1], ' '.join(w[:-1]), yrs), w[-1]

def index_block():
    if not is_full(): return ''
    texts = {}
    for f in CTX['files']:
        m = re.search(r'_veha_(\w+)\.md$', f)
        if m: texts[m.group(1)] = open(os.path.join(SRC, f), encoding='utf8').read()
    order = [v for vs in PART_VEHAS.values() for v in vs]
    ent = []; seen = set()
    for code in order:
        for name, yrs, line in D.V.get(code, {}).get('ppl') or []:
            if name in seen or name in SKIP: continue
            seen.add(name)
            rx = re.compile(person_rx(name))
            hits = [v for v in order if v in texts and rx.search(texts[v])]
            if name in NEAR:
                h0 = order.index(code); hits = [v for v in hits if abs(order.index(v) - h0) <= 4]
            if code not in hits: hits = sorted(set(hits + [code]), key=order.index)
            lab, key = display(name, yrs)
            ent.append((key.replace('ё', 'е').lower(), lab, hits))
    ent.sort()
    L = ['# Именной указатель', '', '[]{#index}*После имени — номера вех, где упоминается человек; номер — ссылка на веху.*', '']
    letter = ''
    for key, lab, hits in ent:
        if key[0].upper() != letter:
            letter = key[0].upper(); L += ['', '**%s**' % letter, '']
        L.append('-   %s — %s' % (lab, ', '.join(vlink(v, num(v)) for v in hits)))
    return '\n'.join(L) + '\n'

def answers_block():
    codes = [v for vs in PART_VEHAS.values() for v in vs if v in CTX['codes'] and D2.QA.get(v)]
    if not codes: return ''
    L = ['# Ответы на вопросы «Проверь себя»', '', '[]{#answers}*Сначала ответьте сами, потом сверяйтесь. Номер вехи — ссылка на неё.*', '']
    for v in codes:
        L += ['**%s**' % vlink(v, 'Веха ' + num(v)), '']
        for n, (q, a) in enumerate(D2.QA[v], 1): L.append('%d.  %s' % (n, a))
        L.append('')
    return '\n'.join(L) + '\n'

def tail():
    return '\n\n' + answers_block() + '\n\n' + index_block()
