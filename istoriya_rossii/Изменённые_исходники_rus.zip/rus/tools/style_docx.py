# -*- coding: utf-8 -*-
"""Оформление собранного Word-файла учебного материала (после pandoc).

python3 -I tools/style_docx.py файл.docx [...]

Что делает:
- заголовки: части — бордовые с золотой линией; вехи — тёмно-синяя плашка с новой страницы;
  темы — бордовые; слои — с цветной полосой слева;
- «Суть вехи» — в рамке цвета пергамента;
- блоки «Тестовые ловушки», «Спорное», «Слой 3 — Дух эпохи», карточки войн — цветные рамки;
- даты, выделенные полужирным, — бордовым цветом (их легче находить глазами);
- метки [ФАКТ], [ОЦЕНКА], [ГИПОТЕЗА], [ЦИТАТА], [ЛЕТОПИСЬ], [ЛЕГЕНДА] — цветные значки;
- таблицы — тёмная шапка и чередование строк;
- подзаголовки хроники (абзац из одного полужирного текста) — синие.
Повторный запуск безопасен (файл помечается).
"""
import sys, os, re, zipfile, copy
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
NS = {'w': W, 'wp': WP, 'a': A}
def q(t): return '{%s}%s' % (W, t)

BURG = '7A1F1F'; NAVY = '1F3A5F'; GOLD = 'B8860B'
MARK = 'style_docx v2'

BOXES = [  # (признак заголовка H4, заливка, полоса)
    (re.compile(r'^Ключевые деятели'), 'F1F4F8', '44546A'),
    (re.compile(r'^Понятия вехи'), 'F3F7F1', '4E7A3A'),
    (re.compile(r'^Связь с другими вехами'), 'EEF2F7', '5B7A99'),
    (re.compile(r'^Проверь себя'), 'FFF6E5', 'D2691E'),
    (re.compile(r'^Картина эпохи'), 'F1F4F8', '44546A'),
    (re.compile(r'^Запомнить для ЕГЭ'), 'EAF4EA', '2E7D32'),
    (re.compile(r'^Главные события эпохи'), 'FBF5E6', 'B8860B'),
    (re.compile(r'^Блок «Тестовые ловушки»|^Тестовые ловушки'), 'FCEDEB', 'C0392B'),
    (re.compile(r'^Спорное'), 'F4EEF9', '6A1B9A'),
    (re.compile(r'^Слой 3'), 'F8F2E6', '8B5A2B'),
]
CARD = ('EEF3F9', '2E5496')       # карточки войн
ICONS = [(re.compile(r'^Понятия вехи'), '\u2139'), (re.compile(r'^Связь с другими вехами'), '\u21C4'), (re.compile(r'^Проверь себя'), '\u2753'), (re.compile(r'^Ключевые деятели'), '\u265B'), (re.compile(r'^Картина эпохи'), '\u25A3'), (re.compile(r'^Запомнить для ЕГЭ'), '\u2714'), (re.compile(r'^Главные события эпохи'), '\u2605'), (re.compile(r'ловушки'), '\u26A0'), (re.compile(r'^Спорное'), '\u2696'), (re.compile(r'^Слой 3'), '\u2726'), (re.compile(r'.'), '\u2694')]
ESSENCE = ('FBF5E6', GOLD)        # «Суть вехи»

TAGS = {
    'ФАКТ': ('2E7D32', 'E8F3E9'), 'ОЦЕНКА': ('9A6400', 'FBF1DC'), 'ГИПОТЕЗА': ('6A1B9A', 'F1E8F7'),
    'ЦИТАТА': ('1F5F96', 'E6EFF8'), 'ЛЕТОПИСЬ': ('7A4A1F', 'F4EBDF'), 'ЛЕГЕНДА': ('7A4A1F', 'F4EBDF'),
}
TAG_RE = re.compile(r'\[(%s)\]' % '|'.join(TAGS))
DATE_RE = re.compile(r'^\s*(\d|[IVXLC]+\s*(—|–|-)?\s*[IVXLC]*\s*в|(около|конец|начало|середина|осень|весна|лето|зима|январь|февраль|март|апрель|май|июнь|июль|август|сентябрь|октябрь|ноябрь|декабрь)\s+\d)', re.I)

CONTENT_W = 9751   # ширина текста, twips (A4, поля образца)
BOX_PAD = 170

def el(tag, **attrs):
    e = etree.Element(q(tag))
    for k, v in attrs.items(): e.set(q(k), str(v))
    return e

def sub(parent, tag, **attrs):
    e = el(tag, **attrs); parent.append(e); return e

def style_of(p):
    s = p.find('w:pPr/w:pStyle', NS)
    return s.get(q('val')) if s is not None else ''

def text_of(p):
    return ''.join(t.text or '' for t in p.iter(q('t')))

def get_pPr(p):
    pPr = p.find('w:pPr', NS)
    if pPr is None:
        pPr = el('pPr'); p.insert(0, pPr)
    return pPr

def set_child(parent, tag, order_before=(), **attrs):
    """Ставит (заменяет) дочерний элемент."""
    old = parent.find('w:' + tag, NS)
    if old is not None: parent.remove(old)
    e = el(tag, **attrs)
    # порядок элементов в pPr/rPr для Word важен лишь частично; добавляем после pStyle
    if tag != 'pStyle' and parent.find('w:pStyle', NS) is not None and parent.tag == q('pPr'):
        parent.find('w:pStyle', NS).addnext(e)
    elif parent.tag == q('rPr') and parent.find('w:rStyle', NS) is not None:
        parent.find('w:rStyle', NS).addnext(e)
    else:
        parent.insert(0, e)
    return e

def heading_level(p):
    m = re.match(r'^Heading(\d)$', style_of(p))
    return int(m.group(1)) if m else 0

# ---------------------------------------------------------------- стили
def patch_styles(x):
    def rep(sid, body):
        nonlocal x
        x2 = re.sub(r'<w:style [^>]*w:styleId="%s"[^>]*>.*?</w:style>' % sid, body, x, count=1, flags=re.S)
        if x2 == x and ('w:styleId="%s"' % sid) not in x:
            x2 = x.replace('</w:styles>', body + '</w:styles>')
        x = x2
    F = '<w:rFonts w:ascii="Calibri" w:cs="Calibri" w:hAnsi="Calibri"/>'
    rep('Heading1', '<w:style w:customStyle="1" w:styleId="Heading1" w:type="paragraph"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:keepLines/><w:pageBreakBefore/><w:pBdr><w:bottom w:color="%s" w:space="6" w:sz="18" w:val="single"/></w:pBdr>'
        '<w:spacing w:after="240" w:before="600"/><w:outlineLvl w:val="0"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="40"/><w:szCs w:val="40"/></w:rPr></w:style>' % (GOLD, F, BURG))
    rep('Heading2', '<w:style w:customStyle="1" w:styleId="Heading2" w:type="paragraph"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:keepLines/><w:pBdr><w:left w:color="%s" w:space="8" w:sz="36" w:val="single"/></w:pBdr>'
        '<w:shd w:fill="%s" w:color="auto" w:val="clear"/><w:spacing w:after="200" w:before="240" w:line="264" w:lineRule="auto"/><w:ind w:left="170" w:right="0"/><w:outlineLvl w:val="1"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="FFFFFF"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>' % (GOLD, NAVY, F))
    rep('Heading3', '<w:style w:customStyle="1" w:styleId="Heading3" w:type="paragraph"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:keepLines/><w:pBdr><w:bottom w:color="%s" w:space="3" w:sz="6" w:val="single"/></w:pBdr><w:spacing w:after="120" w:before="320"/><w:outlineLvl w:val="2"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="27"/><w:szCs w:val="27"/></w:rPr></w:style>' % (GOLD, F, BURG))
    rep('Heading4', '<w:style w:customStyle="1" w:styleId="Heading4" w:type="paragraph"><w:name w:val="heading 4"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:keepLines/><w:pBdr><w:left w:color="%s" w:space="6" w:sz="24" w:val="single"/></w:pBdr><w:spacing w:after="100" w:before="260"/><w:ind w:left="120"/><w:outlineLvl w:val="3"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>' % (NAVY, F, NAVY))
    rep('Heading5', '<w:style w:customStyle="1" w:styleId="Heading5" w:type="paragraph"><w:name w:val="heading 5"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:after="60" w:before="200"/><w:outlineLvl w:val="4"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:smallCaps/><w:color w:val="%s"/><w:spacing w:val="6"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>' % (F, BURG))
    rep('Title', '<w:style w:customStyle="1" w:styleId="Title" w:type="paragraph"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Subtitle"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:pBdr><w:bottom w:color="%s" w:space="12" w:sz="18" w:val="single"/></w:pBdr><w:spacing w:after="360" w:before="2600"/><w:jc w:val="center"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="56"/><w:szCs w:val="56"/></w:rPr></w:style>' % (GOLD, F, BURG))
    rep('Subtitle', '<w:style w:customStyle="1" w:styleId="Subtitle" w:type="paragraph"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="BodyText"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:after="600" w:before="0"/><w:jc w:val="center"/></w:pPr>'
        '<w:rPr>%s<w:i/><w:color w:val="%s"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>' % (F, NAVY))
    rep('VehaTag', '<w:style w:customStyle="1" w:styleId="VehaTag" w:type="paragraph"><w:name w:val="VehaTag"/><w:basedOn w:val="Normal"/><w:next w:val="Heading2"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="60"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:caps/><w:color w:val="%s"/><w:spacing w:val="30"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>' % (F, GOLD))
    rep('Epigraph', '<w:style w:customStyle="1" w:styleId="Epigraph" w:type="paragraph"><w:name w:val="Epigraph"/><w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="160" w:after="20" w:line="276" w:lineRule="auto"/><w:ind w:left="3400"/><w:jc w:val="right"/></w:pPr>'
        '<w:rPr><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria" w:cs="Cambria"/><w:i/><w:color w:val="3A3A3A"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>')
    rep('EpigraphAuthor', '<w:style w:customStyle="1" w:styleId="EpigraphAuthor" w:type="paragraph"><w:name w:val="EpigraphAuthor"/><w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:spacing w:before="0" w:after="200"/><w:ind w:left="3400"/><w:jc w:val="right"/></w:pPr>'
        '<w:rPr>%s<w:smallCaps/><w:color w:val="7F7F7F"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr></w:style>' % F)
    rep('PartYears', '<w:style w:customStyle="1" w:styleId="PartYears" w:type="paragraph"><w:name w:val="PartYears"/><w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="240"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:color w:val="%s"/><w:sz w:val="34"/><w:szCs w:val="34"/></w:rPr></w:style>' % (F, GOLD))
    rep('PersonPic', '<w:style w:customStyle="1" w:styleId="PersonPic" w:type="paragraph"><w:name w:val="PersonPic"/><w:basedOn w:val="Normal"/><w:next w:val="PersonName"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="0"/><w:jc w:val="center"/></w:pPr><w:rPr><w:sz w:val="4"/><w:szCs w:val="4"/></w:rPr></w:style>')
    rep('PersonName', '<w:style w:customStyle="1" w:styleId="PersonName" w:type="paragraph"><w:name w:val="PersonName"/><w:basedOn w:val="Normal"/><w:next w:val="PersonInfo"/><w:qFormat/>'
        '<w:pPr><w:keepNext/><w:spacing w:before="20" w:after="20" w:line="240" w:lineRule="auto"/></w:pPr>'
        '<w:rPr>%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>' % (F, NAVY))
    rep('PersonInfo', '<w:style w:customStyle="1" w:styleId="PersonInfo" w:type="paragraph"><w:name w:val="PersonInfo"/><w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:spacing w:before="0" w:after="0" w:line="252" w:lineRule="auto"/></w:pPr>'
        '<w:rPr><w:color w:val="404040"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>')
    rep('PersonNote', '<w:style w:customStyle="1" w:styleId="PersonNote" w:type="paragraph"><w:name w:val="PersonNote"/><w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:spacing w:before="20" w:after="0" w:line="228" w:lineRule="auto"/></w:pPr>'
        '<w:rPr><w:i/><w:iCs/><w:color w:val="7F7F7F"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>')
    return x

# ---------------------------------------------------------------- карточки деятелей и картина эпохи
PCOL = 1250                     # колонка портрета, twips
def people_grid(items, inner_w):
    """Тройки абзацев PersonPic / PersonName / PersonInfo -> таблица без рамок, по 2 человека в ряд."""
    cards = []; out = []; k = 0
    def flush():
        if not cards: return
        tcol = inner_w // 2 - PCOL
        tbl = el('tbl'); tp = sub(tbl, 'tblPr')
        sub(tp, 'tblW', w=str(inner_w), type='dxa'); sub(tp, 'tblInd', w='0', type='dxa')
        b = sub(tp, 'tblBorders')
        for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'): sub(b, side, val='nil')
        sub(tp, 'tblLayout', type='fixed')
        m = sub(tp, 'tblCellMar'); sub(m, 'top', w='60', type='dxa'); sub(m, 'left', w='0', type='dxa'); sub(m, 'bottom', w='60', type='dxa'); sub(m, 'right', w='100', type='dxa')
        sub(tp, 'tblLook', val='0000', firstRow='0', lastRow='0', firstColumn='0', lastColumn='0', noHBand='1', noVBand='1')
        g = sub(tbl, 'tblGrid')
        for _ in range(2): sub(g, 'gridCol', w=str(PCOL)); sub(g, 'gridCol', w=str(tcol))
        for r0 in range(0, len(cards), 2):
            tr = sub(tbl, 'tr'); trp = sub(tr, 'trPr'); sub(trp, 'cantSplit')
            for c in range(2):
                card = cards[r0 + c] if r0 + c < len(cards) else None
                tc1 = sub(tr, 'tc'); t1 = sub(tc1, 'tcPr'); sub(t1, 'tcW', w=str(PCOL), type='dxa'); sub(t1, 'vAlign', val='top')
                tc2 = sub(tr, 'tc'); t2 = sub(tc2, 'tcPr'); sub(t2, 'tcW', w=str(tcol), type='dxa'); tm = sub(t2, 'tcMar'); sub(tm, 'left', w='140', type='dxa'); sub(t2, 'vAlign', val='center')
                if card:
                    tc1.append(card[0])
                    for x in card[1:]: tc2.append(x)
                    pp = get_pPr(card[0]); set_child(pp, 'keepNext', val='0')
                else:
                    tc1.append(el('p')); tc2.append(el('p'))
        out.append(tbl); cards.clear()
    while k < len(items):
        it = items[k]
        if it.tag == q('p') and style_of(it) == 'PersonPic':
            grp = [it]; k += 1
            while k < len(items) and items[k].tag == q('p') and style_of(items[k]) in ('PersonName', 'PersonInfo', 'PersonNote'):
                grp.append(items[k]); k += 1
            cards.append(grp); continue
        if it.tag in (q('bookmarkStart'), q('bookmarkEnd')) and cards:
            k += 1; out.append(it); continue
        flush(); out.append(it); k += 1
    flush()
    return out

def center_figures(items):
    """Картина в рамке — по центру, подпись курсивом под ней."""
    for it in items:
        if it.tag != q('p'): continue
        st = style_of(it)
        if st in ('CaptionedFigure', 'Figure'):
            pp = get_pPr(it); set_child(pp, 'jc', val='center'); set_child(pp, 'keepNext'); set_child(pp, 'spacing', before='120', after='40')
        elif st in ('ImageCaption', 'Caption'):
            pp = get_pPr(it); set_child(pp, 'jc', val='center'); set_child(pp, 'spacing', before='0', after='40')
            for r in it.iter(q('r')):
                rp = r.find('w:rPr', NS)
                if rp is None: rp = el('rPr'); r.insert(0, rp)
                if rp.find('w:i', NS) is None: rp.append(el('i'))
                set_child(rp, 'color', val='595959'); set_child(rp, 'sz', val='18'); set_child(rp, 'szCs', val='18')

# ---------------------------------------------------------------- рамки
def make_box(fill, bar, items, max_img_emu):
    tbl = el('tbl')
    tblPr = sub(tbl, 'tblPr')
    sub(tblPr, 'tblW', w='5000', type='pct')
    sub(tblPr, 'tblInd', w='0', type='dxa')
    b = sub(tblPr, 'tblBorders')
    sub(b, 'top', val='nil'); sub(b, 'left', val='single', sz='36', space='0', color=bar); sub(b, 'bottom', val='nil')
    sub(b, 'right', val='nil'); sub(b, 'insideH', val='nil'); sub(b, 'insideV', val='nil')
    sub(tblPr, 'tblLayout', type='fixed')
    m = sub(tblPr, 'tblCellMar')
    sub(m, 'top', w='100', type='dxa'); sub(m, 'left', w=str(BOX_PAD), type='dxa'); sub(m, 'bottom', w='80', type='dxa'); sub(m, 'right', w=str(BOX_PAD), type='dxa')
    sub(tblPr, 'tblLook', val='0000', firstRow='0', lastRow='0', firstColumn='0', lastColumn='0', noHBand='1', noVBand='1')
    g = sub(tbl, 'tblGrid'); sub(g, 'gridCol', w=str(CONTENT_W))
    tr = sub(tbl, 'tr')
    trPr = sub(tr, 'trPr'); sub(trPr, 'cantSplit', val='0')
    tc = sub(tr, 'tc')
    tcPr = sub(tc, 'tcPr'); sub(tcPr, 'tcW', w=str(CONTENT_W), type='dxa')
    sub(tcPr, 'shd', val='clear', color='auto', fill=fill)
    if any(x.tag == q('p') and style_of(x) == 'PersonPic' for x in items):
        items = people_grid(items, CONTENT_W - 2 * BOX_PAD)
    center_figures(items)
    for it in items:
        tc.append(it)
        for ext in it.iter('{%s}extent' % WP):
            cx, cy = int(ext.get('cx')), int(ext.get('cy'))
            if cx > max_img_emu:
                k = max_img_emu / cx
                ext.set('cx', str(int(cx * k))); ext.set('cy', str(int(cy * k)))
                for ae in it.iter('{%s}ext' % A):
                    if ae.get('cx') == str(cx):
                        ae.set('cx', str(int(cx * k))); ae.set('cy', str(int(cy * k)))
    if tc.find('w:p', NS) is None or tc[-1].tag != q('p'):
        tc.append(el('p'))
    # последний абзац в рамке — без отступа снизу
    last = tc.findall('w:p', NS)[-1]
    lp = get_pPr(last); set_child(lp, 'spacing', before='40', after='0')
    # заголовок рамки — значок
    first = tc.find('w:p', NS)
    if first is not None and heading_level(first) == 4:
        t0 = text_of(first)
        icon = next((ic for rx, ic in ICONS if rx.search(t0)), None)
        r0 = first.find('w:r', NS)
        if icon and r0 is not None:
            r = el('r'); rp = sub(r, 'rPr')
            sub(rp, 'rFonts', ascii='Segoe UI Symbol', hAnsi='Segoe UI Symbol', cs='Segoe UI Symbol')
            sub(rp, 'color', val=bar)
            t = sub(r, 't'); t.text = icon + '\u2002'
            t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
            r0.addprevious(r)
        fp = get_pPr(first); set_child(fp, 'spacing', before='20', after='80')
        pb = fp.find('w:pBdr', NS)
        nb = el('pBdr'); fp.find('w:pStyle', NS).addnext(nb) if fp.find('w:pStyle', NS) is not None else fp.insert(0, nb)
        sub(nb, 'left', val='nil')
        set_child(fp, 'ind', left='0')
        for rr in first.findall('w:r', NS): color_run(rr, bar)
    split_figure_row(tr, tc)
    return tbl

def split_figure_row(tr, tc):
    """Рамка с рисунками (карточка войны с картой и схемой): каждый рисунок с подписью — отдельная неразрывная строка
    таблицы (вместе с заголовком рамки, если рисунок идёт сразу за ним), текст между рисунками — строки, которые могут
    переходить на следующую страницу. Иначе одна огромная строка не помещалась на странице целиком и уезжала,
    оставляя пустое место и «висящий» заголовок раздела («Войны вехи: подробные карточки»)."""
    kids = [c for c in tc if c.tag != q('tcPr')]
    def is_fig(c): return c.tag == q('p') and c.find('.//w:drawing', NS) is not None
    if not any(is_fig(c) for c in kids) or len(kids) < 3: return
    segs = []; cur = []; fig_seg = False
    i = 0
    while i < len(kids):
        c = kids[i]
        if is_fig(c):
            lead = [x for x in cur if x.tag in (q('p'), q('tbl'))]
            keep_head = len(lead) == 1 and heading_level(lead[0]) == 4      # заголовок рамки остаётся с рисунком
            if cur and not keep_head: segs.append((cur, False)); cur = []
            cur.append(c); i += 1
            while i < len(kids) and (kids[i].tag in (q('bookmarkStart'), q('bookmarkEnd')) or style_of(kids[i]) in ('ImageCaption', 'Caption')):
                cur.append(kids[i]); i += 1
            segs.append((cur, True)); cur = []
            continue
        cur.append(c); i += 1
    if cur: segs.append((cur, False))
    segs = [(sg, f) for sg, f in segs if any(x.tag in (q('p'), q('tbl')) for x in sg)]
    if len(segs) < 2: return
    tcPr = tc.find('w:tcPr', NS); prev = tr
    for n, (sg, fig) in enumerate(segs):
        if n == 0:
            row, cell = tr, tc
            row.find('w:trPr/w:cantSplit', NS).set(q('val'), '1' if fig else '0')
        else:
            row = el('tr'); sub(sub(row, 'trPr'), 'cantSplit', val='1' if fig else '0')
            cell = sub(row, 'tc'); cell.append(copy.deepcopy(tcPr))
            for x in sg: cell.append(x)
            prev.addnext(row); prev = row
        last = [x for x in cell if x.tag in (q('p'), q('tbl'))][-1]
        if last.tag != q('p'): cell.append(el('p'))
        if fig:     # неразрывная строка: «не отрывать от следующего» внутри неё не нужно, а LibreOffice из-за него
                    # переносил всю таблицу на новую страницу, оставляя заголовок раздела одного
            for x in cell.findall('w:p', NS): set_child(get_pPr(x), 'keepNext', val='0')
        else:
            if last.tag == q('p'): set_child(get_pPr(last), 'keepNext', val='0')
    return len(segs)

def boxify(body):
    kids = list(body)
    max_img = int((CONTENT_W - 2 * BOX_PAD - 120) * 635)
    i = 0; n_boxes = 0
    in_cards = False
    while i < len(kids):
        e = kids[i]
        if e.tag != q('p'):
            i += 1; continue
        lvl = heading_level(e); txt = text_of(e).strip()
        if lvl in (1, 2, 3):
            in_cards = (lvl == 3 and txt.startswith('Войны вехи'))
        # «Суть вехи»
        if lvl == 0 and txt.startswith('Суть вехи'):
            box = make_box(ESSENCE[0], ESSENCE[1], [], max_img)
            e.addprevious(box)
            box.find('.//w:tc', NS).insert(1, e)
            # убрать пустой абзац-заглушку
            tc = box.find('.//w:tc', NS)
            for p in tc.findall('w:p', NS)[1:]:
                if not text_of(p).strip() and p.find('.//w:drawing', NS) is None: tc.remove(p)
            dropcap(e)
            gap = el('p'); pp = sub(gap, 'pPr'); sub(pp, 'spacing', before='0', after='60')
            sub(sub(pp, 'rPr'), 'sz', val='8'); box.addnext(gap)
            n_boxes += 1; kids = list(body); i = kids.index(box) + 1; continue
        if lvl == 4:
            spec = None
            for rx, fill, bar in BOXES:
                if rx.search(txt): spec = (fill, bar)
            if spec is None and in_cards: spec = CARD
            if spec:
                j = i + 1
                while j < len(kids):
                    k = kids[j]
                    if k.tag == q('sectPr'): break
                    if k.tag == q('p') and (0 < heading_level(k) <= 4 or style_of(k) in ('VehaTag', 'PartYears')): break
                    j += 1
                items = kids[i:j]
                while items and items[-1].tag in (q('bookmarkStart'), q('bookmarkEnd')): items.pop()
                anchor = el('p'); e.addprevious(anchor)
                for it in items: body.remove(it)
                box = make_box(spec[0], spec[1], items, max_img)
                anchor.addprevious(box); body.remove(anchor)
                # небольшой зазор после рамки
                gap = el('p'); pp = sub(gap, 'pPr'); sub(pp, 'spacing', before='0', after='60')
                rp = sub(sub(pp, 'rPr'), 'sz', val='8')
                box.addnext(gap)
                kids = list(body); i = kids.index(box) + 2; n_boxes += 1
                continue
        i += 1
    return n_boxes

# ---------------------------------------------------------------- абзацы и фрагменты
def color_run(r, color, fill=None, bold=None, size=None):
    rPr = r.find('w:rPr', NS)
    if rPr is None:
        rPr = el('rPr'); r.insert(0, rPr)
    set_child(rPr, 'color', val=color)
    if fill: set_child(rPr, 'shd', val='clear', color='auto', fill=fill)
    if bold:
        if rPr.find('w:b', NS) is None: rPr.append(el('b'))
    if size:
        set_child(rPr, 'sz', val=str(size)); set_child(rPr, 'szCs', val=str(size))

def split_tags(p):
    n = 0
    for r in list(p.findall('.//w:r', NS)):
        t = r.find('w:t', NS)
        if t is None or not t.text or '[' not in t.text: continue
        parts = TAG_RE.split(t.text)
        if len(parts) == 1: continue
        # parts: текст, тег, текст, тег, ...
        prev = r
        first = True
        for k, seg in enumerate(parts):
            if seg == '': continue
            nr = copy.deepcopy(r)
            nt = nr.find('w:t', NS); nt.text = (' ' + seg + ' ') if k % 2 == 1 else seg
            nt.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
            if k % 2 == 1:
                fg, bg = TAGS[seg]
                color_run(nr, fg, bg, bold=True, size=15)
                n += 1
            prev.addnext(nr); prev = nr
        r.getparent().remove(r)
    return n

def is_bold(r):
    rPr = r.find('w:rPr', NS)
    if rPr is None: return False
    b = rPr.find('w:b', NS)
    return b is not None and b.get(q('val')) not in ('0', 'false')

def color_dates(p):
    n = 0
    for r in p.findall('w:r', NS):
        t = ''.join(x.text or '' for x in r.findall('w:t', NS))
        if t and is_bold(r) and DATE_RE.match(t):
            rPr = r.find('w:rPr', NS)
            if rPr.find('w:color', NS) is None:
                color_run(r, BURG); n += 1
    return n

def chron_subheads(p):
    """Абзац из одного полужирного фрагмента (подзаголовок хроники) — синий."""
    if style_of(p) not in ('BodyText', 'FirstParagraph', ''): return 0
    runs = [r for r in p.findall('w:r', NS) if ''.join(x.text or '' for x in r.findall('w:t', NS)).strip()]
    if not runs or not all(is_bold(r) for r in runs): return 0
    txt = text_of(p).strip()
    if len(txt) > 140 or txt.endswith('.'): return 0
    for r in runs: color_run(r, NAVY)
    pPr = get_pPr(p)
    set_child(pPr, 'keepNext')
    sp = pPr.find('w:spacing', NS)
    set_child(pPr, 'spacing', before='160', after='60')
    return 1

def veha_pagebreaks(body):
    n = 0
    for p in body.iter(q('p')):
        if heading_level(p) == 2 and re.match(r'^Веха\s', text_of(p).strip()):
            pPr = get_pPr(p)
            if pPr.find('w:pageBreakBefore', NS) is None:
                set_child(pPr, 'pageBreakBefore'); n += 1
    # если веха идёт сразу после заголовка части — разрыв не нужен (часть уже с новой страницы)
    return n

# ---------------------------------------------------------------- таблицы pandoc
def style_tables(body):
    n = 0
    for tbl in body.iter(q('tbl')):
        if tbl.getparent().tag != q('body'): continue
        rows = tbl.findall('w:tr', NS)
        if len(rows) < 2: continue
        tblPr = tbl.find('w:tblPr', NS)
        b = tblPr.find('w:tblBorders', NS)
        if b is not None: tblPr.remove(b)
        b = el('tblBorders')
        for side in ('top', 'bottom'): sub(b, side, val='single', sz='8', space='0', color=NAVY)
        for side in ('left', 'right', 'insideV'): sub(b, side, val='nil')
        sub(b, 'insideH', val='single', sz='4', space='0', color='C9D3E0')
        look = tblPr.find('w:tblLook', NS)
        if look is not None: look.addprevious(b)
        else: tblPr.append(b)
        for ri, tr in enumerate(rows):
            head = ri == 0 and (tr.find('w:trPr/w:tblHeader', NS) is not None or True)
            for tc in tr.findall('w:tc', NS):
                tcPr = tc.find('w:tcPr', NS)
                if tcPr is None: tcPr = el('tcPr'); tc.insert(0, tcPr)
                old = tcPr.find('w:shd', NS)
                if old is not None: tcPr.remove(old)
                if ri == 0:
                    tcPr.append(el('shd', val='clear', color='auto', fill=NAVY))
                    for r in tc.iter(q('r')): color_run(r, 'FFFFFF', bold=True)
                elif ri % 2 == 0:
                    tcPr.append(el('shd', val='clear', color='auto', fill='F2F5FA'))
        trPr = rows[0].find('w:trPr', NS)
        if trPr is None: trPr = el('trPr'); rows[0].insert(0, trPr)
        if trPr.find('w:tblHeader', NS) is None: trPr.append(el('tblHeader'))
        n += 1
    return n


# ---------------------------------------------------------------- цвет частей, буквица
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import extras_data as XD
PCOLOR = {}      # абзац «Суть вехи» -> цвет части

def part_key(txt):
    m = re.match(r'^Часть ([0IVX]+)\.', txt)
    return m.group(1) if m and m.group(1) in XD.PARTS else None

def apply_part_colors(body):
    col = XD.DEFAULT_COLOR
    for e in list(body):
        if e.tag != q('p'): continue
        lvl = heading_level(e); st = style_of(e); txt = text_of(e).strip()
        if lvl == 1:
            k = part_key(txt)
            col = XD.PARTS[k]['color'] if k else XD.DEFAULT_COLOR
            for r in e.iter(q('r')): color_run(r, col)
        elif lvl == 2:
            set_child(get_pPr(e), 'shd', val='clear', color='auto', fill=col)
        elif lvl == 3:
            pPr = get_pPr(e)
            for r in e.iter(q('r')): color_run(r, col)
        elif st in ('VehaTag', 'PartYears'):
            for r in e.iter(q('r')): color_run(r, col)
        elif lvl == 0 and txt.startswith('Суть вехи'):
            PCOLOR[e] = col

def dropcap(e):
    col = PCOLOR.get(e, BURG)
    runs = e.findall('w:r', NS)
    acc = ''
    # убрать «Суть вехи.»
    while runs:
        r = runs[0]; t = r.find('w:t', NS)
        if t is None: e.remove(r); runs.pop(0); continue
        txt = t.text or ''
        need = 'Суть вехи.'
        if len(acc) + len(txt) <= len(need) + 1 and need.startswith((acc + txt).strip()[:len(need)]) and len((acc + txt).strip()) <= len(need):
            acc += txt; e.remove(r); runs.pop(0)
            if acc.strip() == need: break
            continue
        if not acc and txt.startswith(need):
            t.text = txt[len(need):]
        break
    # первая буква или число
    for r in e.findall('w:r', NS):
        t = r.find('w:t', NS)
        if t is None or not (t.text or '').strip(): 
            if t is not None: t.text = ''
            continue
        t.text = t.text.lstrip()
        m = re.match(r'(\d{1,4})', t.text) or re.match(r'([^\W\d_])', t.text)
        if not m: return
        cap = m.group(1); t.text = t.text[len(cap):]
        t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        break
    else:
        return
    lab = el('p'); lp = sub(lab, 'pPr'); sub(lp, 'keepNext'); sub(lp, 'spacing', before='0', after='60')
    lr = sub(lab, 'r'); rp = sub(lr, 'rPr')
    sub(rp, 'rFonts', ascii='Calibri', hAnsi='Calibri', cs='Calibri'); sub(rp, 'b'); sub(rp, 'smallCaps'); sub(rp, 'color', val=GOLD)
    sub(rp, 'spacing', val='20'); sub(rp, 'sz', val='19')
    tt = sub(lr, 't'); tt.text = 'Суть вехи'
    dc = el('p'); dp = sub(dc, 'pPr')
    sub(dp, 'framePr', dropCap='drop', lines='3', hSpace='90', wrap='around', vAnchor='text', hAnchor='text')
    sub(dp, 'spacing', before='0', after='0', line='920', lineRule='exact')
    sub(dp, 'textAlignment', val='baseline')
    dr = sub(dc, 'r'); rp = sub(dr, 'rPr')
    sub(rp, 'rFonts', ascii='Cambria', hAnsi='Cambria', cs='Cambria'); sub(rp, 'b'); sub(rp, 'color', val=col)
    sub(rp, 'position', val='-6'); sub(rp, 'sz', val='96'); sub(rp, 'szCs', val='96')
    dt = sub(dr, 't'); dt.text = cap
    e.addprevious(lab); e.addprevious(dc)

# ---------------------------------------------------------------- разделы: колонтитул вехи и цветной край страницы
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PIC = 'http://schemas.openxmlformats.org/drawingml/2006/picture'
PAGE_W, PAGE_H = 7560310, 10692130     # A4, EMU
STRIP_W = 150000

def header_xml(left, right, color, rid, k):
    def esc(t): return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    strip = ('<w:r><w:drawing><wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="1" behindDoc="1" locked="1" layoutInCell="1" allowOverlap="1">'
             '<wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="page"><wp:posOffset>%d</wp:posOffset></wp:positionH>'
             '<wp:positionV relativeFrom="page"><wp:posOffset>0</wp:posOffset></wp:positionV><wp:extent cx="%d" cy="%d"/>'
             '<wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/><wp:docPr id="%d" name="Край страницы %d"/><wp:cNvGraphicFramePr/>'
             '<a:graphic><a:graphicData uri="%s"><pic:pic><pic:nvPicPr><pic:cNvPr id="%d" name="strip.png"/><pic:cNvPicPr/></pic:nvPicPr>'
             '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
             '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
             '</a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>') % (PAGE_W - STRIP_W, STRIP_W, PAGE_H, 90000 + k, k, PIC, 90000 + k, rid, STRIP_W, PAGE_H)
    rpr = '<w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>%s<w:color w:val="%s"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:hdr xmlns:w="%s" xmlns:r="%s" xmlns:wp="%s" xmlns:a="%s" xmlns:pic="%s">'
            '<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="3" w:color="%s"/></w:pBdr>'
            '<w:tabs><w:tab w:val="right" w:pos="%d"/></w:tabs><w:spacing w:before="0" w:after="0"/><w:jc w:val="left"/></w:pPr>'
            '%s<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r><w:r>%s<w:tab/></w:r><w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:hdr>') % (
            W, R_NS, WP, A, PIC, color, CONTENT_W, strip,
            rpr % ('<w:b/>', color), esc(left), rpr % ('', '595959'), rpr % ('<w:b/>', '404040'), esc(right))

def make_sections(body):
    """Делит документ на разделы (части, своды, вехи); у каждого — свой колонтитул и цвет края."""
    final = body.find('w:sectPr', NS)
    kids = list(body)
    bounds = []
    part = None; part_col = XD.DEFAULT_COLOR; part_short = ''
    for idx, e in enumerate(kids):
        if e.tag != q('p'): continue
        lvl = heading_level(e); st = style_of(e)
        if lvl == 1:
            txt = text_of(e).strip(); k = part_key(txt)
            part_col = XD.PARTS[k]['color'] if k else XD.DEFAULT_COLOR
            part_short = XD.PARTS[k]['short'] if k else txt
            bounds.append((idx, part_short if k else txt, '', part_col))
        elif st == 'VehaTag':
            bounds.append((idx, part_short, text_of(e).strip(), part_col))
    if not bounds: return []
    secs = []
    for n, (idx, left, right, col) in enumerate(bounds):
        b = kids[idx]
        # раздел, который кончается перед b
        prev = b.getprevious()
        sp = copy.deepcopy(final)
        for hr in sp.findall('w:headerReference', NS): sp.remove(hr)
        if n > 0:
            tp = sp.find('w:titlePg', NS)
            if tp is not None: sp.remove(tp)
            sp.insert(0, el('headerReference', type='default'))
            sp[0].set('{%s}id' % R_NS, 'rIdHx%d' % (n - 1))
        if prev is None or prev.tag != q('p') or prev.find('w:pPr/w:sectPr', NS) is not None:
            prev = el('p'); pp = sub(prev, 'pPr'); sub(pp, 'spacing', before='0', after='0', line='20', lineRule='exact')
            sub(sub(pp, 'rPr'), 'sz', val='2'); b.addprevious(prev)
        pPr = get_pPr(prev)
        pPr.append(sp)
        # у границы — без собственного разрыва страницы
        bp = get_pPr(b); set_child(bp, 'pageBreakBefore', val='0')
        secs.append((left, right, col))
    # последний раздел — итоговый sectPr
    for hr in final.findall('w:headerReference', NS): final.remove(hr)
    tp = final.find('w:titlePg', NS)
    if tp is not None: final.remove(tp)
    hr = el('headerReference', type='default'); hr.set('{%s}id' % R_NS, 'rIdHx%d' % (len(secs) - 1))
    final.insert(0, hr)
    return secs

def strip_png(color):
    from PIL import Image
    import io
    im = Image.new('RGB', (4, 4), '#' + color)
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()

# ---------------------------------------------------------------- порядок элементов по схеме OOXML (Word к нему строг)
ORDER = {
 'pPr': 'pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange',
 'rPr': 'ins del moveFrom moveTo rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss imprint noProof snapToGrid vanish webHidden color spacing w kern position sz szCs highlight u effect bdr shd fitText vertAlign rtl cs em lang eastAsianLayout specVanish oMath rPrChange',
 'tcPr': 'cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark',
 'tblPr': 'tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription',
 'trPr': 'cnfStyle divId gridBefore gridAfter wBefore wAfter cantSplit trHeight tblHeader tblCellSpacing jc hidden',
 'sectPr': 'headerReference footerReference footnotePr endnotePr type pgSz pgMar paperSrc pgBorders lnNumType pgNumType cols formProt vAlign noEndnote titlePg textDirection bidi rtlGutter docGrid printerSettings',
 'pBdr': 'top left bottom right between bar',
 'tblBorders': 'top left start bottom right end insideH insideV',
 'tblCellMar': 'top left start bottom right end',
}
ORDER = {k: {n: i for i, n in enumerate(v.split())} for k, v in ORDER.items()}

def normalize(root):
    n = 0
    for tag, rank in ORDER.items():
        for e in root.iter(q(tag)):
            kids = list(e)
            def key(c):
                if not isinstance(c.tag, str): return 999
                ln = etree.QName(c).localname
                return rank.get(ln, 998)
            srt = sorted(kids, key=key)          # устойчивая сортировка
            # дубликаты одного элемента — оставить последний
            seen = {}; ded = []
            for c in srt:
                ln = etree.QName(c).localname if isinstance(c.tag, str) else None
                if ln and ln not in ('headerReference', 'footerReference') and ln in seen and tag != 'pBdr':
                    ded.remove(seen[ln])
                seen[ln] = c; ded.append(c)
            if ded != kids:
                for c in kids: e.remove(c)
                for c in ded: e.append(c)
                n += 1
    return n

def strip_stray_text(root):
    """В styles.xml текста быть не может; в образце ref.docx в стиле AbstractTitle внутри w:rPr был лишний «>» — Word считает это ошибкой."""
    n = 0
    for e in root.iter():
        if not isinstance(e.tag, str): continue
        if e.text and e.text.strip(): e.text = None; n += 1
        if e.tail and e.tail.strip(): e.tail = None; n += 1
    return n

# ---------------------------------------------------------------- главное
def style(path):
    zin = zipfile.ZipFile(path)
    items = [(i, zin.read(i.filename)) for i in zin.infolist()]
    zin.close()
    names = {it.filename for it, _ in items}
    stat = {}
    out = []; secs = []
    PCOLOR.clear()
    for it, data in items:
        if it.filename == 'word/document.xml':
            if MARK.encode() in data:
                print('уже оформлен:', path); return
            root = etree.fromstring(data)
            body = root.find('w:body', NS)
            stat['таблиц'] = style_tables(body)
            stat['дат'] = 0; stat['меток'] = 0; stat['подзаг.'] = 0
            for p in list(body.iter(q('p'))):
                stat['меток'] += split_tags(p)
                stat['дат'] += color_dates(p)
                stat['подзаг.'] += chron_subheads(p)
            apply_part_colors(body)
            stat['рамок'] = boxify(body)
            secs = make_sections(body)
            stat['упорядочено'] = normalize(root)
            stat['разделов'] = len(secs)
            data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
            data = data.replace(b'<w:body>', ('<w:body><!-- %s -->' % MARK).encode(), 1)
        elif it.filename == 'word/styles.xml':
            data = patch_styles(data.decode('utf8')).encode('utf8')
            sr = etree.fromstring(data); normalize(sr); strip_stray_text(sr)          # порядок элементов и в стилях (образец ref.docx его нарушал)
            data = etree.tostring(sr, xml_declaration=True, encoding='UTF-8', standalone=True)
        elif re.match(r'word/(header|footer)\d*\.xml$', it.filename):
            hr = etree.fromstring(data)
            if normalize(hr): data = etree.tostring(hr, xml_declaration=True, encoding='UTF-8', standalone=True)
        out.append((it, data))
    # колонтитулы разделов
    extra = []
    colors = sorted({c for _, _, c in secs})
    for c in colors: extra.append(('word/media/strip_%s.png' % c, strip_png(c)))
    for k, (left, right, col) in enumerate(secs):
        extra.append(('word/hdrx%d.xml' % k, header_xml(left, right, col, 'rIdS', k).encode('utf8')))
        extra.append(('word/_rels/hdrx%d.xml.rels' % k, ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/strip_%s.png"/>'
            '</Relationships>' % col).encode('utf8')))
    out2 = []
    for it, data in out:
        if it.filename == 'word/_rels/document.xml.rels' and secs:
            x = data.decode('utf8')
            add = ''.join('<Relationship Id="rIdHx%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="hdrx%d.xml"/>' % (k, k) for k in range(len(secs)))
            data = x.replace('</Relationships>', add + '</Relationships>').encode('utf8')
        elif it.filename == '[Content_Types].xml' and secs:
            x = data.decode('utf8')
            if 'Extension="png"' not in x:
                x = x.replace('<Default ', '<Default Extension="png" ContentType="image/png"/><Default ', 1)
            add = ''.join('<Override PartName="/word/hdrx%d.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' % k for k in range(len(secs)))
            data = x.replace('</Types>', add + '</Types>').encode('utf8')
        out2.append((it, data))
    tmp = path + '.tmp'
    z = zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED)
    for it, data in out2: z.writestr(it, data)
    for name, data in extra: z.writestr(name, data)
    z.close(); os.replace(tmp, path)
    print('оформлено:', os.path.basename(path), stat)

if __name__ == '__main__':
    for f in sys.argv[1:]: style(f)
