# -*- coding: utf-8 -*-
"""Контрольный список: что из обязательного для ЕГЭ не упоминается в исходниках.

python3 -I tools/control_check.py audit/control_list_1.txt   (основные события, документы, понятия — 360 пунктов)
python3 -I tools/control_check.py audit/control_list_2.txt   (деятели, сражения, детали — 326 пунктов)
Строка списка: период | что ищем | регулярное выражение."""
import re, glob, sys, os
T = {f: open(f, encoding='utf8').read() for f in sorted(glob.glob(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src', '*.md')))}
ALL = '\n'.join(T.values())
L = [l for l in open(sys.argv[1], encoding='utf8').read().split('\n') if l.strip() and not l.startswith('#')]
miss = []
for l in L:
    per, name, rx = [x.strip() for x in l.split('|', 2)]
    n = len(re.findall(rx, ALL, re.I))
    if n == 0: miss.append((per, name))
    elif n <= 1 and '--rare' in sys.argv: print('редко', per, name, n)
for m in miss: print('НЕТ', *m)
print(len(L), 'пунктов; нет', len(miss))
