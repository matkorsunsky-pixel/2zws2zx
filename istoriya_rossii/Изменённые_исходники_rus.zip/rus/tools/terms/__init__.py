# -*- coding: utf-8 -*-
"""Понятия вех: T[код вехи] = [('Понятие', 'определение'), ...].
Используются при сборке (tools/extras.py): рамка «Понятия вехи» в каждой вехе и «Словарь понятий» в конце основного файла.
Определение — что это, когда и где, как связано с вехой. Даты до 1918 г. — по старому стилю (как в материале)."""
import importlib, os
T = {}
for _m in sorted(f[:-3] for f in os.listdir(os.path.dirname(__file__)) if f.startswith('part_') and f.endswith('.py')):
    T.update(importlib.import_module(__name__ + '.' + _m).T)
