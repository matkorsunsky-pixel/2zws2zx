# -*- coding: utf-8 -*-
"""Сборка Word-файла из исходников Markdown.

python3 -I tools/build.py <каталог_исходника> <выход.docx> [--only N-M] [--title "..."] [--subtitle "..."]
                          [--toc-before "Заголовок H1"] [--prefix s] [--no-toc]

Исходник: файлы NNN_*.md (порядок — по имени), каталог media/, файл _meta.json
(title, subtitle, toc_before, prefix, toc_title).
"""
import sys, os, re, json, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
REF = os.path.join(ROOT, 'ref', 'ref.docx')

def read_src(srcdir, files=None, extras=False):
    fs = sorted(f for f in os.listdir(srcdir) if re.match(r'^\d{3}[a-z]?_.*\.md$', f))
    if files is not None:
        fs = [f for f in fs if f in files]
    parts = []
    if extras:
        import extras as X
        X.set_ctx(fs)
        h = X.head()
        if h: parts.append(h.strip('\n'))
    for f in fs:
        t = open(os.path.join(srcdir, f), encoding='utf8').read().strip('\n')
        if extras:
            import extras as X
            t = X.transform(f, t).strip('\n')
        parts.append(t)
    if extras:
        parts.append(X.tail().strip('\n'))
    return '\n\n'.join(p for p in parts if p) + '\n'

def add_contents(md, levels=(1, 2), title='Содержание', prefix='s', before=None, intro=None):
    """Проставляет якоря {#prefix-N} у заголовков и вставляет список-оглавление."""
    L = md.split('\n')
    out = []; toc = []; n = 0; in_code = False
    for l in L:
        if l.startswith('```'):
            in_code = not in_code
        m = None if in_code else re.match(r'^(#{1,6}) (.*)$', l)
        if m and len(m.group(1)) in levels:
            n += 1
            lvl = len(m.group(1)); txt = m.group(2).strip()
            txt = re.sub(r'\s*\{#[^}]*\}\s*$', '', txt)
            out.append('%s %s {#%s-%d}' % (m.group(1), txt, prefix, n))
            toc.append((lvl, txt, n))
        else:
            out.append(l)
    lines = ['# ' + title, '']
    if intro:
        lines += [intro, '']
    base = min(levels)
    for lvl, txt, k in toc:
        lines.append('    ' * (lvl - base) + '-   [%s](#%s-%d)' % (txt, prefix, k))
    lines.append('')
    # куда вставить
    pos = 0
    if before:
        for i, l in enumerate(out):
            if re.match(r'^# ' + re.escape(before) + r'(\s*\{#[^}]*\})?\s*$', l):
                pos = i; break
    return '\n'.join(out[:pos] + lines + out[pos:])

def ref_with_footer(text):
    """Образец оформления с нужной подписью в нижнем колонтитуле."""
    import zipfile, hashlib
    if not text:
        return REF
    h = hashlib.md5(text.encode('utf8')).hexdigest()[:10]
    dst = os.path.join(ROOT, 'ref', 'ref_%s.docx' % h)
    if os.path.exists(dst):
        return dst
    zin = zipfile.ZipFile(REF); zout = zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED)
    for it in zin.infolist():
        data = zin.read(it.filename)
        if it.filename == 'word/footer2.xml':
            x = data.decode('utf8')
            x2 = re.sub(r'(<w:t xml:space="preserve">)[^<]*(  ·  </w:t>)', lambda m: m.group(1) + xml_esc(text) + m.group(2), x, count=1)
            assert x2 != x or text in x, 'не найден текст колонтитула'
            data = x2.encode('utf8')
        zout.writestr(it, data)
    zout.close()
    return dst

def xml_esc(t):
    return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def build(srcdir, outdocx, files=None, title=None, subtitle=None, toc_before=None, prefix=None, no_toc=False, toc_title=None, extra_head=None, levels=None, footer=None, resource=None, md_text=None, extras=False):
    meta = {}
    mp = os.path.join(srcdir, '_meta.json')
    if os.path.exists(mp):
        meta = json.load(open(mp, encoding='utf8'))
    title = title or meta.get('title', '')
    subtitle = subtitle if subtitle is not None else meta.get('subtitle', '')
    toc_before = toc_before if toc_before is not None else meta.get('toc_before')
    prefix = prefix or meta.get('prefix', 's')
    toc_title = toc_title or meta.get('toc_title', 'Содержание')
    levels = tuple(levels or meta.get('levels', (1, 2)))
    footer = footer if footer is not None else meta.get('footer')
    md = md_text if md_text is not None else read_src(srcdir, files, extras)
    if extra_head:
        md = extra_head.strip('\n') + '\n\n' + md
    if not no_toc:
        md = add_contents(md, levels=levels, title=toc_title, prefix=prefix, before=toc_before)
    head = '---\n'
    if title:
        head += 'title: "%s"\n' % title.replace('"', '\\"')
    if subtitle:
        head += 'subtitle: "%s"\n' % subtitle.replace('"', '\\"')
    head += 'lang: ru\n---\n\n'
    md = head + md
    tmp = os.path.join(srcdir, '_render.md')
    open(tmp, 'w', encoding='utf8').write(md)
    cmd = ['pandoc', tmp, '-f', 'markdown+pipe_tables-smart', '-t', 'docx',
           '--reference-doc=' + ref_with_footer(footer), '--standalone',
           '--resource-path=' + os.pathsep.join([srcdir] + list(resource or [])), '-o', outdocx]
    subprocess.check_call(cmd)
    tidy(outdocx)
    return outdocx

def tidy(path):
    """Порядок дочерних элементов по схеме OOXML и чистка лишнего текста — во всех частях файла.
    pandoc пишет, например, numPr раньше pStyle и bCs раньше b; Word строг к порядку и может ответить
    «обнаружено нечитаемое содержимое»."""
    import zipfile
    from lxml import etree
    sys.path.insert(0, HERE)
    from style_docx import normalize, strip_stray_text
    zin = zipfile.ZipFile(path); items = [(i, zin.read(i.filename)) for i in zin.infolist()]; zin.close()
    tmp = path + '.tmp'; z = zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED)
    for it, data in items:
        if re.match(r'word/(document|styles|numbering|header\d*|footer\d*|footnotes)\.xml$', it.filename):
            r = etree.fromstring(data); n = normalize(r) + (strip_stray_text(r) if it.filename == 'word/styles.xml' else 0)
            if n: data = etree.tostring(r, xml_declaration=True, encoding='UTF-8', standalone=True)
        z.writestr(it, data)
    z.close(); os.replace(tmp, path)

if __name__ == '__main__':
    a = sys.argv[1:]
    kw = {}
    def opt(name, key, flag=False):
        if name in a:
            k = a.index(name)
            if flag:
                kw[key] = True; del a[k]
            else:
                kw[key] = a[k + 1]; del a[k:k + 2]
    opt('--title', 'title'); opt('--subtitle', 'subtitle'); opt('--toc-before', 'toc_before')
    opt('--prefix', 'prefix'); opt('--no-toc', 'no_toc', True); opt('--toc-title', 'toc_title')
    build(a[0], a[1], **kw)
    print('собрано:', a[1], os.path.getsize(a[1]))
