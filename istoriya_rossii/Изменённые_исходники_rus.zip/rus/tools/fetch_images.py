# -*- coding: utf-8 -*-
"""Портреты и картины эпохи с Wikimedia Commons: загрузка, обрезка, список источников.

python3 -I tools/fetch_images.py --contact ВАШ_EMAIL          # докачать недостающие файлы
python3 -I tools/fetch_images.py --contact ВАШ_EMAIL --force  # перекачать все
python3 -I tools/fetch_images.py --credits                    # только audit/images_credits.md и src/118_pril_I_illustracii.md

Что откуда берётся — audit/images_choice.json (выбор сделан вручную и проверен глазами):
  portraits: slug -> {file: имя файла на Commons, note: пометка в подписи или null, box: [x0, y0, x1, y1] — рамка обрезки
             в долях (null — подобрать автоматически), checked: просмотрен ли результат глазами}
  art:       код вехи -> {file, note}
  skip_portraits / skip_art: что пропущено и почему.
Сведения о лицензиях и авторах — audit/images_meta.json (снимок страниц Commons; обновляется при загрузке).

Правила Wikimedia (https://w.wiki/4wJS): в User-Agent нужен контакт (--contact или переменная WIKIMEDIA_CONTACT);
качать миниатюры стандартных размеров (https://w.wiki/GHai), а не оригиналы; не спешить. Скрипт делает паузы и
при ответе 429 ждёт. Берутся только файлы со свободной лицензией (общественное достояние, CC0, CC BY, CC BY-SA).
Подготовка: портреты — 300×380, JPEG 80, ≤ 40 КБ; картины — ширина ≤ 1200, JPEG 75, ≤ 180 КБ.
"""
import sys, os, re, io, json, time, datetime

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
CHOICE = os.path.join(ROOT, 'audit', 'images_choice.json')
META = os.path.join(ROOT, 'audit', 'images_meta.json')
PORT = os.path.join(ROOT, 'src', 'media', 'portraits'); ART = os.path.join(ROOT, 'src', 'media', 'art')
API = 'https://commons.wikimedia.org/w/api.php'
STD = [120, 250, 330, 500, 960, 1280, 1920]

def free(lic):
    l = (lic or '').lower()
    return bool(re.match(r'^(public domain|pd|cc0|cc by(-sa)?( \d\.\d)?|cc-by|cc-by-sa)', l)) and 'nc' not in l and 'nd' not in l

def strip(h): return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', h or '')).strip()

# ---------------------------------------------------------------- сеть
class Net:
    def __init__(self, contact):
        import requests
        self.s = requests.Session()
        self.s.headers['User-Agent'] = 'RusHistoryTextbookBuilder/1.0 (%s) python-requests' % contact
        self.last = 0.0
    def get(self, url, params=None, pause=3.0, raw=False, tries=6):
        for k in range(tries):
            dt = time.time() - self.last
            if dt < pause: time.sleep(pause - dt)
            self.last = time.time()
            p = dict(params, format='json', maxlag=5) if params else None
            r = self.s.get(url, params=p, timeout=90)
            if r.status_code == 429:
                w = min(max(int(r.headers.get('retry-after', '30') or 30), 20), 700)
                print('  429, пауза %d с' % w, file=sys.stderr); time.sleep(w); continue
            if r.status_code != 200: return None
            return r.content if raw else r.json()
        return None

def imageinfo(net, files):
    out = {}
    for k in range(0, len(files), 40):
        ch = files[k:k + 40]
        j = net.get(API, dict(action='query', titles='|'.join('File:' + f for f in ch), prop='imageinfo', iiprop='url|size|extmetadata',
                              iiextmetadatafilter='LicenseShortName|Artist|ObjectName', redirects=1))
        if not j: continue
        q = j['query']; nm = {n['to']: n['from'] for n in q.get('normalized', [])}
        for p in q['pages'].values():
            ii = (p.get('imageinfo') or [None])[0]
            if not ii: continue
            em = ii.get('extmetadata', {})
            out[nm.get(p['title'], p['title'])[5:]] = dict(url=ii['url'].split('?')[0], width=ii['width'], height=ii['height'],
                page=ii.get('descriptionurl'), license=strip(em.get('LicenseShortName', {}).get('value')), artist=strip(em.get('Artist', {}).get('value')))
    return out

def thumb_urls(m, sizes):
    mm = re.match(r'(https://upload\.wikimedia\.org/wikipedia/commons)/(\w)/(\w\w)/(.+)$', m['url'])
    if not mm: return []
    base, a, ab, name = mm.groups(); res = []
    for s in sizes:
        if s >= m['width']: continue
        t = '%s/thumb/%s/%s/%s/%dpx-%s' % (base, a, ab, name, s, name)
        if name.lower().endswith('.svg'): t += '.png'
        res.append(t)
    return res

# ---------------------------------------------------------------- обработка
def save_jpeg(im, path, q, maxkb):
    while True:
        b = io.BytesIO(); im.save(b, 'JPEG', quality=q, optimize=True, progressive=True)
        if b.tell() <= maxkb * 1024 or q <= 40: break
        q -= 4
    open(path, 'wb').write(b.getvalue())

def auto_box(im):
    """Рамка «голова и плечи», если её нет в images_choice.json: по лицу (OpenCV, если установлен) или верх изображения."""
    w, h = im.size; R = 380 / 300
    face = None
    try:
        import cv2, numpy as np
        c = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, 'haarcascade_frontalface_default.xml'))
        g = cv2.equalizeHist(cv2.cvtColor(np.array(im), cv2.COLOR_RGB2GRAY))
        fs = [f for f in c.detectMultiScale(g, 1.08, 5, minSize=(max(14, w // 14),) * 2) if f[1] + f[3] / 2 < 0.75 * h]
        if fs: face = max(fs, key=lambda f: f[2] * f[3])
    except Exception:
        pass
    if face is not None:
        x, y, fw, fh = face; bh = fh * 3.0; bw = bh / R; cx = x + fw / 2; top = y - 0.6 * fh
    else:
        bw = w; bh = bw * R; cx = w / 2; top = 0.02 * h
    if bw > w: bw = w; bh = bw * R
    if bh > h: bh = h; bw = bh / R
    left = min(max(cx - bw / 2, 0), w - bw); top = min(max(top, 0), h - bh)
    return [left / w, top / h, (left + bw) / w, (top + bh) / h]

def make_portrait(data, box, dst):
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert('RGB'); w, h = im.size
    x0, y0, x1, y1 = box or auto_box(im)
    c = im.crop((round(x0 * w), round(y0 * h), round(x1 * w), round(y1 * h))).resize((300, 380), Image.LANCZOS)
    save_jpeg(c, dst, 80, 40)

def make_art(data, dst):
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert('RGB')
    if im.width > 1200: im = im.resize((1200, round(im.height * 1200 / im.width)), Image.LANCZOS)
    save_jpeg(im, dst, 75, 180)

def fetch(contact, force=False):
    C = json.load(open(CHOICE, encoding='utf8'))
    meta = json.load(open(META, encoding='utf8')) if os.path.exists(META) else {}
    net = Net(contact)
    jobs = [(os.path.join(PORT, s + '.jpg'), v['file'], 'p', v) for s, v in C['portraits'].items()] + \
           [(os.path.join(ART, 'veha_%s.jpg' % k), v['file'], 'a', v) for k, v in C['art'].items()]
    todo = [j for j in jobs if force or not os.path.exists(j[0])]
    print('нужно скачать:', len(todo))
    meta.update(imageinfo(net, sorted({j[1] for j in todo})))
    json.dump(meta, open(META, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
    os.makedirs(PORT, exist_ok=True); os.makedirs(ART, exist_ok=True)
    bad = []
    for dst, f, kind, v in todo:
        m = meta.get(f)
        if not m: bad.append((f, 'нет на Commons')); continue
        if not free(m['license']): bad.append((f, 'несвободная лицензия: ' + m['license'])); continue
        data = None
        for u in thumb_urls(m, [500, 330, 960, 250] if kind == 'p' else [1280, 960]):
            data = net.get(u, raw=True, pause=6.0, tries=3)
            if data and data[:3] in (b'\xff\xd8\xff', b'\x89PN'): break
            data = None
        if not data: bad.append((f, 'не скачалось')); continue
        (make_portrait(data, v['box'], dst) if kind == 'p' else make_art(data, dst))
        print('  ok', os.path.relpath(dst, ROOT))
    for f, why in bad: print('  НЕ ВЫШЛО:', f, '—', why)
    credits()

# ---------------------------------------------------------------- список источников и приложение И
def credits():
    import extras_data as D, extras as X
    C = json.load(open(CHOICE, encoding='utf8')); meta = json.load(open(META, encoding='utf8'))
    def author(a):
        a = re.sub(r'(Unknown author)\s*\1', r'\1', a or ''); a = re.sub(r'^(.+?)\s+\1$', r'\1', a)
        a = re.sub(r'^(?:photo by|Photo:)\s*', '', a, flags=re.I)
        if not a or re.fullmatch(r'(?i)unknown( author| artist)?|anonymous|неизвестный автор|автор неизвестен', a): return 'неизвестный автор'
        if re.fullmatch(r'(?i)collective( of Kremlin Armoury| of Kremlin armory)?|Царский титулярник|Collective of authors of Titul.*', a): return 'мастера «Царского титулярника»'
        return a.replace('|', '/')[:120]
    def lic(l): return 'общественное достояние' if re.match(r'(?i)public domain|^pd', l or '') else l
    names, where = {}, {}
    for code, d in D.V.items():
        for n, y, l in d.get('ppl') or []:
            names.setdefault(X.slug(n), (n, y)); where.setdefault(X.slug(n), []).append(X.num(code))
    rows = []
    for s, v in C['portraits'].items():
        if not os.path.exists(os.path.join(PORT, s + '.jpg')) or v['file'] not in meta: continue
        m = meta[v['file']]
        rows.append(('%s.jpg' % s, '%s (%s)' % names[s], author(m['artist']), lic(m['license']), m['page'], ', '.join(dict.fromkeys(where[s])), v.get('note') or '—', 'p'))
    for k, v in C['art'].items():
        if not os.path.exists(os.path.join(ART, 'veha_%s.jpg' % k)) or v['file'] not in meta: continue
        m = meta[v['file']]; a = D.V[k]['art']
        rows.append(('veha_%s.jpg' % k, '«%s» (%s)' % a, author(m['artist']), lic(m['license']), m['page'], X.num(k), v.get('note') or '—', 'a'))
    today = datetime.date.today().isoformat()
    L = ['# Источники иллюстраций: портреты и картины эпохи', '',
         'Все изображения — с Wikimedia Commons; лицензия проверена на странице файла (%s). Портреты обрезаны до головы и плеч (300×380), '
         'картины уменьшены до 1200 px по ширине. Колонка «Пометка» выводится в подписи при сборке (tools/extras.py). '
         'Выбор файлов и рамки обрезки — audit/images_choice.json; загрузка — tools/fetch_images.py.' % today, '',
         '## Вставлено (портретов: %d, картин: %d)' % (sum(r[7] == 'p' for r in rows), sum(r[7] == 'a' for r in rows)), '',
         '| Файл | Что изображено | Автор | Лицензия | Страница Commons | Вехи | Пометка |', '|---|---|---|---|---|---|---|']
    for r in rows:
        L.append('| `%s` | %s%s | %s | %s | %s | %s | %s |' % (r[0], 'Портрет: ' if r[7] == 'p' else 'Картина эпохи: ', r[1], r[2], r[3], r[4], r[5], r[6]))
    L += ['', '## Пропущено (в материале осталась текстовая ссылка или имя без портрета)', '', '| Файл | Кто / что | Причина |', '|---|---|---|']
    for s, why in C['skip_portraits'].items(): L.append('| `%s.jpg` | %s (%s) | %s |' % (s, names[s][0], names[s][1], why))
    for k, why in C['skip_art'].items(): L.append('| `veha_%s.jpg` | «%s» (%s) | %s |' % (k, D.V[k]['art'][0], D.V[k]['art'][1], why))
    miss = [s for s in C['portraits'] if not os.path.exists(os.path.join(PORT, s + '.jpg'))] + \
           ['veha_' + k for k in C['art'] if not os.path.exists(os.path.join(ART, 'veha_%s.jpg' % k))]
    if miss:
        L += ['', '## Выбрано, но ещё не скачано', '', 'Запустите `python3 -I tools/fetch_images.py --contact ВАШ_EMAIL`: ' + ', '.join('`%s`' % m for m in miss) + '.']
    open(os.path.join(ROOT, 'audit', 'images_credits.md'), 'w', encoding='utf8').write('\n'.join(L) + '\n')
    P = ['# Приложение И. Источники иллюстраций', '',
         'Портреты в рамках «Ключевые деятели» и картины эпохи взяты с Wikimedia Commons (commons.wikimedia.org). Они используются на условиях '
         'указанных лицензий: общественное достояние или Creative Commons (CC0, CC BY, CC BY-SA; для CC BY и CC BY-SA обязательно указание автора и '
         'лицензии, тексты лицензий — на creativecommons.org/licenses). Изображения обрезаны и уменьшены. Пометка «условное изображение» означает, '
         'что прижизненного портрета нет и показан поздний или иконописный образ (например, из «Царского титулярника» 1672 г.). '
         'Карты, шкалы времени и схемы составлены для этого материала и в таблицу не входят.', '']
    for kind, title in (('p', 'Портреты'), ('a', 'Картины эпохи и памятники')):
        rr = [r for r in rows if r[7] == kind]
        if not rr: continue
        P += ['### ' + title, '', '| Изображение | Автор | Лицензия | Источник |', '|----------------------------------------|----------------|------------|----------|']
        for r in rr:
            what = r[1] + ('' if r[6] == '—' else ' — ' + r[6]) + (' — веха %s' % r[5] if kind == 'a' else '')
            P.append('| %s | %s | %s | [Wikimedia Commons](%s) |' % (what.replace('|', '/'), r[2], r[3], r[4].replace(')', '%29').replace('(', '%28')))
        P.append('')
    open(os.path.join(ROOT, 'src', '118_pril_I_illustracii.md'), 'w', encoding='utf8').write('\n'.join(P) + '\n')
    print('списки источников обновлены: портретов %d, картин %d' % (sum(r[7] == 'p' for r in rows), sum(r[7] == 'a' for r in rows)))

if __name__ == '__main__':
    a = sys.argv[1:]
    if '--credits' in a: credits(); sys.exit(0)
    contact = os.environ.get('WIKIMEDIA_CONTACT')
    if '--contact' in a: contact = a[a.index('--contact') + 1]
    if not contact: sys.exit('Нужен контакт для User-Agent (правила Wikimedia): --contact ВАШ_EMAIL или переменная WIKIMEDIA_CONTACT')
    fetch(contact, force='--force' in a)
