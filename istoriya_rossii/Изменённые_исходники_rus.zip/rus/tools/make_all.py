# -*- coding: utf-8 -*-
"""Собирает все файлы курса «История России» из исходников.

python3 -I tools/make_all.py [каталог_вывода] [--only main,toma,zip,an,ex,paket,guide,assist,backup]

По умолчанию вывод — /mnt/user-data/outputs.
"""
import sys, os, re, json, zipfile, shutil, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import build, gen_an, gen_ex, shrink_docx, style_docx, check_docx

SRC = os.path.join(ROOT, 'src'); SRC_AN = os.path.join(ROOT, 'src_an'); SRC_EX = os.path.join(ROOT, 'src_ex'); SRC_GUIDE = os.path.join(ROOT, 'src_guide'); SRC_ASSIST = os.path.join(ROOT, 'src_assist')
WORK = os.path.join(ROOT, '_work')

def files():
    return sorted(f for f in os.listdir(SRC) if re.match(r'^\d{3}[a-z]?_.*\.md$', f))

def idx(fs, pat):
    for i, f in enumerate(fs):
        if re.search(pat, f): return i
    raise SystemExit('нет файла ' + pat)

ZIP_NAMES = ['00_Введение_периодизация_словарь.docx', '00а_Часть_0_Древнейшая_история.docx', '01_Часть_I_Истоки_Руси_IX_в_–_1240.docx',
             '02_Часть_II_Ордынский_период_1223–1533.docx', '03_Часть_III_Иван_Грозный_и_Смута_1533–1613.docx',
             '04_Часть_IV_Романовы_и_империя_1613–1801.docx', '05_Часть_V_XIX_век_1801–1894.docx',
             '06_Часть_VI_Николай_II_1894–1917.docx', '07_Часть_VII_1918–1953.docx', '08_Часть_VIII_1953–1991.docx',
             '09_Часть_IX_1991–2026.docx', '10_Справочные_приложения.docx']
PARTS = ['0', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX']
PAKET_NAMES = ['00_Период_0_Древность.docx', '01_Период_I.docx', '02_Период_II.docx', '03_Период_III.docx', '04_Период_IV.docx', '05_Период_IV-Б_1725-1801.docx',
               '06_Период_V.docx', '07_Период_VI.docx', '08_Период_VII.docx', '09_Период_VIII.docx', '10_Период_IX.docx', '11_Сквозные_линии.docx']

def h1_title(f):
    l = open(os.path.join(SRC, f), encoding='utf8').readline().strip()
    return re.sub(r'^#+\s*', '', l)

def prompt_md(txt):
    out = []
    for i, l in enumerate(txt.strip('\n').split('\n')):
        l = l.rstrip()
        if not l: continue
        if i == 0: out.append('**' + l + '**'); continue
        if re.match(r'^\d+\. ', l): out.append('**' + l + '**'); continue
        if l.startswith('— '): out.append('-   ' + l[2:]); continue
        if re.match(r'^\d+\) ', l): out.append(re.sub(r'^(\d+)\)', r'\1\\)', l)); continue
        out.append(l)
    return '\n\n'.join(out)

def main():
    a = sys.argv[1:]
    only = None
    if '--only' in a:
        k = a.index('--only'); only = set(a[k + 1].split(',')); del a[k:k + 2]
    out = a[0] if a else '/mnt/user-data/outputs'
    os.makedirs(out, exist_ok=True); os.makedirs(WORK, exist_ok=True)
    fs = files()
    T = 'История России. Итоговый учебный материал'
    want = lambda k: only is None or k in only
    res = []
    if want('main'):
        p = os.path.join(out, 'История_России_итоговый_учебный_материал.docx')
        build.build(SRC, p, extras=True); style_docx.style(p); shrink_docx.shrink(p); res.append(p)
    iV = idx(fs, r'_chast_V\.md$'); iI = idx(fs, r'_chast_0\.md$'); iA = idx(fs, r'_spravocnye_prilozenia\.md$')
    if want('toma'):
        p = os.path.join(out, 'История_России_итоговый_учебный_материал_Том_1.docx')
        build.build(SRC, p, files=set(fs[:iV]), title=T + '. Том 1', subtitle='Древнейшие времена — 1801 г.: введение, словарь, части 0–IV и IV-Б',
                    footer='История России. Том 1', extras=True); style_docx.style(p); shrink_docx.shrink(p); res.append(p)
        p = os.path.join(out, 'История_России_итоговый_учебный_материал_Том_2.docx')
        build.build(SRC, p, files=set(fs[iV:]), title=T + '. Том 2', subtitle='1801–2026 гг.: части V–IX и справочные приложения',
                    footer='История России. Том 2', toc_before='', extras=True); style_docx.style(p); shrink_docx.shrink(p); res.append(p)
    if want('zip'):
        tmp = os.path.join(WORK, 'zip'); shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
        bounds = [0, iI] + [idx(fs, r'_chast_%s\.md$' % r) for r in PARTS[1:]] + [iA, len(fs)]
        for n in range(len(ZIP_NAMES)):
            sub = fs[bounds[n]:bounds[n + 1]]
            p = os.path.join(tmp, ZIP_NAMES[n])
            if n == 0:
                build.build(SRC, p, files=set(sub), title=T, subtitle='Введение, периодизация, хронологическая таблица вех и словарь',
                            footer='История России. Введение', extras=True)
            elif n == len(ZIP_NAMES) - 1:
                build.build(SRC, p, files=set(sub), title=T, subtitle='Справочные приложения: сквозные линии, журнал правок, реестры, соответствие нумерации',
                            footer='История России. Справочные приложения', toc_before='', extras=True)
            else:
                build.build(SRC, p, files=set(sub), title=T, subtitle=h1_title(sub[0]), footer='История России. Часть ' + PARTS[n - 1], toc_before='', extras=True)
        for n in ZIP_NAMES: style_docx.style(os.path.join(tmp, n)); shrink_docx.shrink(os.path.join(tmp, n))
        zp = os.path.join(out, 'История_России_по_периодам.zip')
        with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
            for n in ZIP_NAMES: z.write(os.path.join(tmp, n), n)
        res.append(zp)
    if want('an') or want('paket'):
        an = os.path.join(WORK, 'an'); shutil.rmtree(an, ignore_errors=True)
        gen_an.gen(SRC, SRC_AN, an)
        if want('an'):
            p = os.path.join(out, 'Анализ_истории_России_по_эпохам_рабочая_версия.docx')
            build.build(an, p, resource=[SRC]); res.append(p)
        if want('paket'):
            tmp = os.path.join(WORK, 'paket'); shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
            afs = sorted(f for f in os.listdir(an) if re.match(r'^\d{3}[a-z]?_.*\.md$', f))
            for n, f in enumerate(afs[2:2 + len(PAKET_NAMES)]):
                build.build(an, os.path.join(tmp, PAKET_NAMES[n]), files={f}, title='', subtitle='', no_toc=True, footer='', resource=[SRC])
            shutil.copy(os.path.join(SRC_AN, '_paket_instr.txt'), os.path.join(tmp, '00_Инструкция_и_промпт.txt'))
            zp = os.path.join(out, 'Пакет_для_внешней_критики.zip')
            with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
                for n in ['00_Инструкция_и_промпт.txt'] + PAKET_NAMES: z.write(os.path.join(tmp, n), n)
            res.append(zp)
    if want('ex'):
        ex = os.path.join(WORK, 'ex'); shutil.rmtree(ex, ignore_errors=True)
        gen_ex.gen(SRC, SRC_EX, ex)
        p = os.path.join(out, 'Извлечение_данных_История_России.docx')
        build.build(ex, p, resource=[SRC]); res.append(p)
    if want('guide') and os.path.isdir(SRC_GUIDE):
        p = os.path.join(out, 'Пособие_как_изучать_историю_России.docx')
        build.build(SRC_GUIDE, p, resource=[SRC]); shrink_docx.shrink(p); res.append(p)
    if want('assist') and os.path.isdir(SRC_ASSIST):
        txt = open(os.path.join(SRC_ASSIST, 'prompt.txt'), encoding='utf8').read()
        tmp = os.path.join(WORK, 'assist'); shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp)
        shutil.copy(os.path.join(SRC_ASSIST, '_meta.json'), tmp)
        for f in os.listdir(SRC_ASSIST):
            if f.endswith('.md'):
                open(os.path.join(tmp, f), 'w', encoding='utf8').write(open(os.path.join(SRC_ASSIST, f), encoding='utf8').read().replace('{{PROMPT}}', prompt_md(txt)))
        p = os.path.join(out, 'Положение_о_работе_ИИ-ассистента.docx')
        build.build(tmp, p, resource=[SRC]); res.append(p)
        p = os.path.join(out, 'Промпт_для_ИИ-ассистента.txt')
        open(p, 'w', encoding='utf8').write(txt); res.append(p)
    if want('backup'):
        zp = os.path.join(out, 'История_России_исходники_для_сборки.zip')
        tmpz = zp + '.tmp'
        with zipfile.ZipFile(tmpz, 'w', zipfile.ZIP_DEFLATED) as z:
            for base in ('src', 'src_an', 'src_ex', 'src_guide', 'src_assist', 'guide', 'tools', 'maps', 'ref', 'audit', 'figs'):
                d = os.path.join(ROOT, base)
                if not os.path.isdir(d): continue
                for r, ds, ff in os.walk(d):
                    ds[:] = [x for x in ds if x not in ('__pycache__', 'out_tmp')]
                    for f in ff:
                        if f in ('_render.md',) or f.endswith('.pyc') or re.match(r'^ref_[0-9a-f]+\.docx$', f): continue
                        full = os.path.join(r, f)
                        z.write(full, os.path.join('rus', os.path.relpath(full, ROOT)))
            rd = os.path.join(ROOT, 'README.md')
            if os.path.exists(rd): z.write(rd, 'rus/README.md')
        os.replace(tmpz, zp); res.append(zp)
    for p in res:
        if p.endswith('.docx'): check_docx.check(p, verbose=bool(check_docx.check(p, verbose=False)))   # печать — только если есть ошибки
        print('%10d  %s' % (os.path.getsize(p), os.path.basename(p)))

if __name__ == '__main__':
    main()
