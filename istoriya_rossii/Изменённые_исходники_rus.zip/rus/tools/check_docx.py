# -*- coding: utf-8 -*-
"""Проверка собранного .docx на типичные причины сообщения Word «обнаружено нечитаемое содержимое».

python3 -I tools/check_docx.py файл.docx

Проверяет: разбор всех XML-частей; связи (r:id, r:embed) и цели связей; типы содержимого ([Content_Types].xml);
уникальность wp:docPr/@id; парность и уникальность закладок; ссылки w:hyperlink/@w:anchor на существующие закладки;
таблицы (tblGrid, у каждой ячейки последний элемент — абзац, число ячеек = числу колонок);
порядок дочерних элементов pPr/rPr/tblPr/tcPr/trPr/sectPr по схеме; sectPr — только в pPr или в конце body.
"""
import sys, os, re, zipfile, posixpath
from collections import Counter
from lxml import etree
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from style_docx import ORDER, NS, q, W, R_NS

PR = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'

def check(path, verbose=True):
    z = zipfile.ZipFile(path); names = set(z.namelist()); errs = []
    def E(m):
        errs.append(m)
    xml = {}
    for n in names:
        if n.endswith('.xml') or n.endswith('.rels'):
            try: xml[n] = etree.fromstring(z.read(n))
            except Exception as e: E('XML не разбирается: %s: %s' % (n, e))
    # типы содержимого
    ct = xml.get('[Content_Types].xml')
    dflt = {d.get('Extension').lower() for d in ct.findall('{%s}Default' % CT)}
    over = {o.get('PartName') for o in ct.findall('{%s}Override' % CT)}
    for n in names:
        if n.endswith('/'): continue
        if '/' + n not in over and n.rsplit('.', 1)[-1].lower() not in dflt: E('нет типа содержимого: ' + n)
    for o in over:
        if o[1:] not in names: E('Override на несуществующую часть: ' + o)
    # связи
    rels = {}
    for n in names:
        if not n.endswith('.rels'): continue
        base = posixpath.dirname(posixpath.dirname(n)); part = posixpath.join(base, posixpath.basename(n)[:-5])
        ids = {}
        for r in xml[n].findall('{%s}Relationship' % PR):
            if r.get('Id') in ids: E('повтор Id связи %s в %s' % (r.get('Id'), n))
            ids[r.get('Id')] = r
            if r.get('TargetMode') != 'External':
                t = posixpath.normpath(posixpath.join(base, r.get('Target'))) if not r.get('Target').startswith('/') else r.get('Target')[1:]
                if t not in names: E('связь %s в %s ведёт на несуществующий %s' % (r.get('Id'), n, t))
        rels[part] = ids
    docpr = Counter(); bm_names = Counter(); anchors = set()
    for n, root in xml.items():
        if not (n.startswith('word/') and not n.startswith('word/_rels')): continue
        rid = rels.get(n, {})
        for e in root.iter():
            if not isinstance(e.tag, str): continue
            for k, v in e.attrib.items():
                if k.startswith('{%s}' % R_NS) and k.split('}')[1] in ('id', 'embed', 'link') and v not in rid:
                    E('%s: ссылка %s=%s без связи' % (n, k.split('}')[1], v))
        for d in root.iter('{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}docPr'):
            docpr[d.get('id')] += 1
        TXT = {q('t'), q('instrText'), q('delText'), '{http://schemas.openxmlformats.org/drawingml/2006/main}t', '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}posOffset',
               '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}align'}
        for e in root.iter():
            if isinstance(e.tag, str) and e.tag not in TXT and e.text and e.text.strip(): E('%s: лишний текст %r внутри %s' % (n, e.text.strip()[:20], etree.QName(e).localname))
            if isinstance(e.tag, str) and e.tail and e.tail.strip(): E('%s: лишний текст %r после %s' % (n, e.tail.strip()[:20], etree.QName(e).localname))
        # закладки
        st = {}; en = Counter()
        for b in root.iter(q('bookmarkStart')):
            if b.get(q('id')) in st: E('%s: повтор id закладки %s' % (n, b.get(q('id'))))
            st[b.get(q('id'))] = b.get(q('name')); bm_names[b.get(q('name'))] += 1
        for b in root.iter(q('bookmarkEnd')): en[b.get(q('id'))] += 1
        for i in st:
            if en[i] != 1: E('%s: у закладки %s (%s) концов: %d' % (n, i, st[i], en[i]))
        for i in en:
            if i not in st: E('%s: конец закладки %s без начала' % (n, i))
        for h in root.iter(q('hyperlink')):
            if h.get(q('anchor')): anchors.add(h.get(q('anchor')))
        # таблицы
        for t in root.iter(q('tbl')):
            g = t.find('w:tblGrid', NS)
            if t.find('w:tblPr', NS) is None or g is None: E('%s: таблица без tblPr/tblGrid' % n); continue
            ncol = len(g.findall('w:gridCol', NS))
            if not t.findall('w:tr', NS): E('%s: таблица без строк' % n)
            for tr in t.findall('w:tr', NS):
                span = sum(int((tc.find('w:tcPr/w:gridSpan', NS).get(q('val')) if tc.find('w:tcPr/w:gridSpan', NS) is not None else 1)) for tc in tr.findall('w:tc', NS))
                if span != ncol: E('%s: в строке %d ячеек при %d колонках' % (n, span, ncol))
                for tc in tr.findall('w:tc', NS):
                    kids = [c for c in tc if isinstance(c.tag, str) and c.tag not in (q('tcPr'), q('bookmarkStart'), q('bookmarkEnd'))]
                    if not kids or kids[-1].tag != q('p'): E('%s: ячейка не кончается абзацем' % n)
        # порядок
        for tag, rank in ORDER.items():
            for e in root.iter(q(tag)):
                ks = [rank.get(etree.QName(c).localname, 998) for c in e if isinstance(c.tag, str)]
                if ks != sorted(ks): E('%s: порядок элементов в %s: %s' % (n, tag, [etree.QName(c).localname for c in e])); break
        if n == 'word/document.xml':
            body = root.find('w:body', NS)
            for s in root.iter(q('sectPr')):
                p = s.getparent()
                if not (p.tag == q('pPr') or (p is body and s is body[-1])): E('sectPr не на месте')
                for c in ('pgSz', 'pgMar'):
                    if s.find('w:' + c, NS) is None: E('sectPr без ' + c)
    for i, c in docpr.items():
        if c > 1: E('повтор wp:docPr id=%s (%d раз)' % (i, c)); 
    for nm, c in bm_names.items():
        if c > 1: E('повтор имени закладки %s (%d раз)' % (nm, c))
    for a in sorted(anchors):
        if a not in bm_names: E('ссылка на несуществующую закладку: #' + a)
    if verbose:
        print(os.path.basename(path), 'ошибок:', len(errs))
        cnt = Counter(re.sub(r'\d+', 'N', e)[:90] for e in errs)
        for k, v in cnt.most_common(40): print('  %5d  %s' % (v, k))
        for e in errs[:15]: print('   пример:', e[:200])
    return errs

if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]: bad += len(check(p))
    sys.exit(1 if bad else 0)
