# -*- coding: utf-8 -*-
"""Вставляет в вехи разделы «Подробный разбор: хозяйство, общество и процессы» из audit/deep/part_*.py.

python3 -I tools/insert_deep.py            — вставить (повторный запуск заменяет ранее вставленный раздел)
Раздел ставится перед «### Спорные вопросы вехи» или «### Войны вехи», иначе — в конец вехи.
Текст раздела хранится в audit/deep/ — его удобно править и вставлять заново."""
import os, re, sys, glob, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, 'src'); DEEP = os.path.join(ROOT, 'audit', 'deep')
MARK0 = '<!-- deep:start -->'; MARK1 = '<!-- deep:end -->'

def load():
    D = {}
    for p in sorted(glob.glob(os.path.join(DEEP, 'part_*.py'))):
        spec = importlib.util.spec_from_file_location(os.path.basename(p)[:-3], p)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); D.update(m.D)
    return D

def main():
    D = load(); n = 0
    for f in sorted(glob.glob(os.path.join(SRC, '*_veha_*.md'))):
        code = re.search(r'_veha_(\w+)\.md$', f).group(1)
        if code not in D: continue
        t = open(f, encoding='utf8').read()
        t = re.sub(r'\n*' + re.escape(MARK0) + r'.*?' + re.escape(MARK1) + r'\n*', '\n\n', t, flags=re.S)
        block = MARK0 + '\n\n' + D[code].strip('\n') + '\n\n' + MARK1
        m = re.search(r'^### (Спорные вопросы вехи|Войны вехи)', t, re.M)
        if m: t = t[:m.start()].rstrip('\n') + '\n\n' + block + '\n\n' + t[m.start():]
        else: t = t.rstrip('\n') + '\n\n' + block + '\n'
        open(f, 'w', encoding='utf8').write(t); n += 1
    print('вставлено разделов:', n)

if __name__ == '__main__':
    main()
